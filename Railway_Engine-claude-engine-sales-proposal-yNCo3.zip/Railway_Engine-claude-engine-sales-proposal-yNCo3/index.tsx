import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.tsx';

// REMOVED: import './index.css'; 
// Browsers cannot natively import CSS files in ES Modules without a bundler.
// The styles have been moved to index.html <style> block.

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);