
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  // Load env file based on `mode` in the current working directory.
  const env = loadEnv(mode, (process as any).cwd(), '');
  
  // Safe define: Only expose process.env.API_KEY if we have a local value.
  // This allows AI Studio / IDX environments to inject their own process.env.API_KEY at runtime
  // without being overwritten by an undefined static string replacement.
  const defines: Record<string, string> = {
    'process.env.VITE_TACTICS_URL': JSON.stringify(env.VITE_TACTICS_URL),
  };

  if (env.API_KEY || env.VITE_API_KEY) {
      defines['process.env.API_KEY'] = JSON.stringify(env.API_KEY || env.VITE_API_KEY);
  }

  return {
    plugins: [react()],
    base: './', 
    define: defines,
    optimizeDeps: {
      exclude: ['@google/genai', 'pdfjs-dist', 'recharts', 'dompurify']
    },
    build: {
      outDir: 'dist',
      sourcemap: false, 
      target: 'esnext',
      rollupOptions: {
        // Externalize dependencies served via importmap (CDN) to prevent bundling
        external: [
          'react', 
          'react-dom', 
          'react-dom/client', 
          'recharts', 
          '@google/genai', 
          'pdfjs-dist', 
          'dompurify'
        ]
      }
    }
  };
});
