
import { generateBatchSystemInstruction, generateBatchUserPrompt } from './prompts';
// ✅ FIXED: Import from ROOT knowledge_base to match others
import { BATCH_DEFINITIONS } from './knowledge_base';
import { GoogleGenAI } from "@google/genai";

// ✅ SECURE PARSER: Handles "Dirty" JSON
const parseAiResponse = (text: string): any => {
  if (!text) return {};
  let cleaned = text.trim();
  cleaned = cleaned.replace(/```json/gi, '').replace(/```/g, '');
  const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    console.warn("AI Response contained no JSON braces. Raw:", text);
    return {};
  }
  const jsonString = jsonMatch[0];
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    console.error("❌ JSON Parse Failed. Raw Text:", text);
    throw new Error("AI response was not valid JSON.");
  }
};

// ✅ HYBRID GENERATION (Orchestrator Version)
const callHybridGenerate = async (model: string, contents: any[], systemInstruction: string) => {
    
    // STRATEGY A: DIRECT CLIENT SDK (DEV/PREVIEW)
    // If we are in Dev or not on Vercel, use the SDK directly.
    // SAFE CHECK: use optional chaining to prevent crashing if import.meta.env is undefined
    const isDev = (import.meta as any)?.env?.DEV;

    if (isDev || !window.location.host.includes('vercel.app')) {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
            model: model,
            contents: contents,
            config: {
                systemInstruction: systemInstruction,
                responseMimeType: "application/json"
            }
        });
        return { text: response.text };
    }

    // STRATEGY B: SECURE PROXY (PROD)
    // Vercel Pro Timeout is set to 600s (10 mins). We set safety at 595s.
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 595000);

    try {
        const response = await fetch('/api/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model,
                contents,
                systemInstruction 
            }),
            signal: controller.signal
        });

        if (!response.ok) {
            if (response.status === 404) {
                // Fallback for Preview deployments that might lack the API route
                clearTimeout(timeoutId);
                const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
                const fallbackResponse = await ai.models.generateContent({
                    model: model,
                    contents: contents,
                    config: {
                        systemInstruction: systemInstruction,
                        responseMimeType: "application/json"
                    }
                });
                return { text: fallbackResponse.text };
            }
            const errorText = await response.text();
            throw new Error(`Proxy Error (${response.status}): ${errorText}`);
        }

        const data = await response.json();
        if (data.error) throw new Error(data.error);
        return data;
    } finally {
        clearTimeout(timeoutId);
    }
};

export const runPhase1Audit = async (text: string, onProgress: (completed: number, total: number) => void): Promise<any> => {
  const batches = ['A', 'B', 'C', 'D', 'E'];
  const totalBatches = batches.length;
  
  const aggregatedResults = {
    phase_1_audit_logs: {
      adaptability: {},
      taylorism: {}
    }
  };

  let completedCount = 0;

  // ✅ PARALLEL EXECUTION: Fire all streams at once
  const auditPromises = batches.map(async (batchId) => {
    try {
      const definitions = BATCH_DEFINITIONS[batchId as keyof typeof BATCH_DEFINITIONS];
      const systemInstruction = generateBatchSystemInstruction(batchId, definitions.title);
      const userPrompt = generateBatchUserPrompt(batchId, definitions);

      // ✅ GEMINI 3.0 FLASH: Fastest model for parallel audits
      const response = await callHybridGenerate(
        'gemini-3-flash-preview', 
        [
            { 
                role: 'user', 
                parts: [
                    { text: userPrompt }, // Part 1: Instructions
                    { text: `\n\n<UNTRUSTED_CONTENT>\n${text}\n</UNTRUSTED_CONTENT>` } // Part 2: Document (Sandboxed)
                ] 
            }
        ],
        systemInstruction
      );

      try {
          const batchResult = parseAiResponse(response.text);
          if (batchResult.adaptability) Object.assign(aggregatedResults.phase_1_audit_logs.adaptability, batchResult.adaptability);
          if (batchResult.taylorism) Object.assign(aggregatedResults.phase_1_audit_logs.taylorism, batchResult.taylorism);
      } catch (parseError) {
          console.error(`Error Parsing Batch ${batchId}:`, parseError);
      }

    } catch (error) {
      console.error(`Error processing Batch ${batchId}:`, error);
    } finally {
      completedCount++;
      onProgress(completedCount, totalBatches);
    }
  });

  await Promise.all(auditPromises);
  return aggregatedResults;
};
