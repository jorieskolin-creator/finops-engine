
// Real-time performance monitoring for the diagnostic engine
// Handles telemetry logging without retaining sensitive data

export class PerformanceMonitor {
    private static marks: Map<string, number> = new Map();

    /**
     * Start a performance timer
     * @param label Unique identifier for the operation
     */
    static start(label: string) {
        this.marks.set(label, performance.now());
    }

    /**
     * End a performance timer and log the duration
     * @param label Unique identifier for the operation
     */
    static end(label: string) {
        const startTime = this.marks.get(label);
        if (startTime) {
            const duration = performance.now() - startTime;
            // Use a distinct styling for performance logs in the console
            console.debug(`%c⚡ [FastTrack] ${label}: ${duration.toFixed(2)}ms`, 'color: #8b5cf6; font-weight: bold;');
            this.marks.delete(label);
            return duration;
        }
        return 0;
    }

    /**
     * Log a telemetry event (Dev only to prevent console noise in Prod)
     */
    static logEvent(event: string, details?: any) {
        // In a real production app, this would push to Datadog/Sentry
        // Here we keep it local but structured
        // SAFE CHECK: Use optional chaining to prevent crash
        if ((import.meta as any)?.env?.DEV) {
            console.log(`%c📡 [Telemetry] ${event}`, 'color: #06b6d4;', details || '');
        }
    }

    /**
     * Safe error logging that ensures errors are visible but flagged
     */
    static logError(context: string, error: any) {
        console.error(`%c🚨 [System Failure] ${context}`, 'background: #fee2e2; color: #991b1b; padding: 2px 4px; border-radius: 4px;', error);
    }
}
    