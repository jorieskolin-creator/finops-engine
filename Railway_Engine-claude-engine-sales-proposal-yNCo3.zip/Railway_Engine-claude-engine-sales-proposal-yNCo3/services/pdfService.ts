
import * as pdfjsLib from 'pdfjs-dist';

// ✅ FIXED: Hardcoded Worker URL to match importmap version (4.8.69)
// Using esm.sh/pdfjs-dist@4.8.69/build/pdf.worker.min.mjs ensures compatibility 
// with the main library loaded in index.html and avoids unpkg CORS issues.
(pdfjsLib as any).GlobalWorkerOptions.workerSrc = `https://esm.sh/pdfjs-dist@4.8.69/build/pdf.worker.min.mjs`;

export const extractTextFromPdf = async (file: File): Promise<string> => {
  try {
    const arrayBuffer = await file.arrayBuffer();
    
    // Load the document
    const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
    const pdf = await loadingTask.promise;
    
    let fullText = '';

    // Loop through all pages
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items
        .map((item: any) => item.str)
        .join(' ');
      
      fullText += `--- Page ${i} ---\n${pageText}\n\n`;
    }

    return fullText;
  } catch (error) {
    console.error("PDF Extraction Failed:", error);
    throw new Error(`Failed to parse PDF: ${(error as Error).message}.`);
  }
};
