import { ScanResult } from "../types.ts";

// Expanded list: Includes General Strategy + Modernization + Architecture terms
const STRATEGIC_KEYWORDS = [
    // General Strategy & Business
    "strategy", "strategic", "organization", "organisation", "team", "culture",
    "process", "management", "leadership", "budget", "planning", "delivery",
    "product", "service", "customer", "value", "agile", "waterfall",
    "stakeholder", "decision", "governance", "innovat", "efficien",
    "market", "roadmap", "objective", "key result", "okr", "kpi",
    "audit", "risk", "compliance", "vision", "mission", "values",
    
    // Modernization & Operating Model (NEW)
    "transformation", "legacy", "modernization", "operating model", "taxonomy",
    "domain", "capability", "enablement", "silo", "friction", "autonomy",
    "alignment", "cross-functional", "value stream", "handoff",
    
    // Technical Architecture & Engineering (NEW)
    "architecture", "platform", "cloud", "microservices", "api", "integration",
    "deployment", "pipeline", "automation", "scale", "resilience", "reliability",
    "security", "tech debt", "technical debt", "refactoring",
    
    // Flow Metrics (NEW)
    "velocity", "throughput", "lead time", "cycle time", "wip", "work in progress",
    "flow", "bottleneck", "constraint"
];

// Common document headers that indicate structure
const STRUCTURAL_HEADERS = [
    "executive summary", "introduction", "background", "scope", 
    "roadmap", "conclusion", "recommendation", "next steps", "appendix"
];

export const sanitizeInput = (text: string): string => {
    let clean = text;
    
    // 1. Emails
    clean = clean.replace(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g, '[EMAIL_REDACTED]');
    
    // 2. IPv4 Addresses
    clean = clean.replace(/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g, '[IP_REDACTED]');
    
    // 3. Phone Numbers (Generic International & US formats)
    clean = clean.replace(/(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/g, '[PHONE_REDACTED]');

    return clean;
};

export const scanInputText = (text: string): ScanResult => {
    const cleanText = text.trim();
    
    // 1. CHECK LENGTH
    const wordCount = cleanText.split(/\s+/).length;
    
    if (wordCount === 0) {
        return {
            score: 0,
            status: 'Insufficient',
            message: "Waiting for input...",
            details: [],
            canRun: false
        };
    }

    if (wordCount < 50) {
        return {
            score: 10,
            status: 'Insufficient',
            message: "Input too short",
            details: [`Word count: ${wordCount} (Min: 50). The AI needs more context.`],
            canRun: false
        };
    }

    // 2. CHECK KEYWORD DENSITY (Relevance)
    const lowerText = cleanText.toLowerCase();
    const uniqueKeywords = new Set<string>();

    STRATEGIC_KEYWORDS.forEach(keyword => {
        if (lowerText.includes(keyword)) {
            uniqueKeywords.add(keyword);
        }
    });

    // 3. CHECK STRUCTURE (Headers)
    let structureBonus = 0;
    const foundHeaders: string[] = [];
    STRUCTURAL_HEADERS.forEach(header => {
        if (lowerText.includes(header)) {
            structureBonus += 5; // 5 points per header found
            foundHeaders.push(header);
        }
    });
    // Cap structure bonus at 20
    structureBonus = Math.min(structureBonus, 20);


    // 4. SCORING LOGIC
    let score = 0; 
    const details = [];

    // Length Bonus (Max 20 pts)
    if (wordCount > 100) score += 10;
    if (wordCount > 500) score += 10;

    // Relevance Bonus (Max 60 pts)
    // Each unique strategic keyword is worth 3 points.
    const keywordScore = Math.min(uniqueKeywords.size * 3, 60);
    score += keywordScore;

    // Structure Bonus (Max 20 pts)
    score += structureBonus;

    // Cap at 100
    score = Math.min(score, 100);

    // 5. DETERMINE STATUS
    let status: 'Ready' | 'Weak' | 'Insufficient' = 'Insufficient';
    let message = "Irrelevant Content";
    let canRun = false;

    if (score >= 60) {
        status = 'Ready';
        message = "High Quality Signal";
        details.push(`Detected ${uniqueKeywords.size} strategic topics`);
        if (foundHeaders.length > 0) details.push(`Identified document structure (${foundHeaders.length} headers)`);
        canRun = true;
    } else if (score >= 30) {
        status = 'Weak';
        message = "Weak Signal";
        details.push("Some strategic keywords found, but context may be thin.");
        canRun = true;
    } else {
        status = 'Insufficient';
        message = "Noise Detected";
        details.push("Document appears irrelevant to strategy (e.g. password list, invoice, generic text).");
        canRun = false;
    }

    return {
        score,
        status,
        message,
        details,
        canRun
    };
};