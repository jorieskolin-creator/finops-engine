
import { STRATEGY_SYSTEM_INSTRUCTION, STRATEGY_USER_PROMPT } from "../constants";
import { runPhase1Audit } from "../orchestrator";
// ✅ FIXED: Import from ROOT knowledge_base.ts to match UI components
import { knowledgeBaseService, BATCH_DEFINITIONS } from "../knowledge_base.ts";
import { DiagnosticResult, Phase1AuditLogs, Phase2Validation, Phase3Strategy, Metrics, AuditItem } from "../types";
import { generateSafetyAuditPrompt } from "./securityService"; 
import { GoogleGenAI } from "@google/genai";

const ALL_CRITERIA_IDS = [
  'A1', 'A2', 'A3', 'A4', 'A5',
  'B1', 'B2', 'B3', 'B4', 'B5',
  'C1', 'C2', 'C3', 'C4', 'C5',
  'D1', 'D2', 'D3', 'D4', 'D5',
  'E1', 'E2', 'E3', 'E4', 'E5'
];

const parseAiResponse = (text: string): any => {
  if (!text) return {};
  let cleaned = text.replace(/```json/gi, '').replace(/```/g, '').trim();
  const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
      console.warn("AI Response contained no JSON braces.");
      return {}; 
  }
  const jsonString = jsonMatch[0];
  try {
      return JSON.parse(jsonString);
  } catch (e) {
      console.error("❌ FATAL PARSE ERROR. Raw Text:", text);
      throw new Error("AI response was malformed and could not be repaired safely.");
  }
};

// ✅ HYBRID GENERATION SERVICE
// Switches between Direct SDK (for GAS/Dev) and Proxy (for Vercel/Prod)
const callHybridGenerate = async (model: string, contents: any[], systemInstruction?: string) => {
    
    // 1. DEVELOPMENT MODE (Google AI Studio / Local)
    // If we are in Dev OR if the Proxy previously failed, use the SDK directly.
    // SAFE CHECK: Use optional chaining to prevent crash if import.meta.env is undefined
    const isDev = (import.meta as any)?.env?.DEV; 
    
    if (isDev || !window.location.host.includes('vercel.app')) {
        console.log(`[HybridService] Running in DEV/PREVIEW mode. Using Client-Side SDK for ${model}.`);
        
        if (!process.env.API_KEY) {
            throw new Error("API Key missing in environment. Please check .env file.");
        }

        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        // Helper to convert chat-style contents to generateContent format if needed
        const response = await ai.models.generateContent({
            model: model,
            contents: contents, // Pass the chat history/contents directly
            config: {
                systemInstruction: systemInstruction,
                responseMimeType: "application/json"
            }
        });

        return { text: response.text };
    }

    // 2. PRODUCTION MODE (Vercel)
    // Use the Secure Proxy to hide the API Key
    console.log(`[HybridService] Running in PROD mode. Using Secure Proxy for ${model}.`);
    const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model, contents, systemInstruction })
    });

    if (!response.ok) {
        // Fallback: If proxy fails (e.g., 404 in preview), try SDK one last time
        if (response.status === 404) {
             console.warn("[HybridService] Proxy 404. Falling back to SDK.");
             const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
             const fallbackResponse = await ai.models.generateContent({
                model: model,
                contents: contents,
                config: {
                    systemInstruction: systemInstruction,
                    responseMimeType: "application/json"
                }
            });
            return { text: fallbackResponse.text };
        }
        throw new Error(`Proxy Error: ${response.statusText}`);
    }

    const data = await response.json();
    if (data.error) throw new Error(data.error);
    return data; 
};

const validateAndSanitizeLogs = (rawData: any): Phase1AuditLogs => {
  const safeLog: Phase1AuditLogs = { adaptability: {}, taylorism: {} };

  const validateItem = (item: any, isTaylorism: boolean): AuditItem => {
    if (!item || typeof item !== 'object') {
        return { count: -1, status: "NOK", evidence: "AI Analysis Failed", is_silent: true, reasoning: "Data missing." };
    }
    const safeItem: AuditItem = { count: 0, status: "NOK", evidence: "Evidence extracted.", is_silent: false, reasoning: "No reasoning provided." };
    if (typeof item.count === 'number') { safeItem.count = Math.min(Math.max(item.count, 0), 3); }

    if (isTaylorism) {
        if (safeItem.count === 0) { safeItem.status = "OK"; safeItem.is_silent = true; safeItem.evidence = "No rigidity detected. (Clean)"; } 
        else if (safeItem.count === 3) { safeItem.status = "NOK"; safeItem.is_silent = false; } 
        else { safeItem.status = "Partial"; safeItem.is_silent = false; }
    } else {
        if (safeItem.count === 3) { safeItem.status = "OK"; safeItem.is_silent = false; } 
        else if (safeItem.count === 0) { safeItem.status = "NOK"; safeItem.is_silent = true; safeItem.evidence = "Capability missing."; } 
        else { safeItem.status = "Partial"; safeItem.is_silent = false; }
    }
    if (typeof item.evidence === 'string' && item.evidence.length > 5) safeItem.evidence = item.evidence;
    if (typeof item.reasoning === 'string') safeItem.reasoning = item.reasoning;
    return safeItem;
  };

  const rawAdapt = rawData?.phase_1_audit_logs?.adaptability || {};
  ALL_CRITERIA_IDS.forEach(id => safeLog.adaptability[id] = validateItem(rawAdapt[id], false));
  const rawTaylor = rawData?.phase_1_audit_logs?.taylorism || {};
  ALL_CRITERIA_IDS.forEach(id => safeLog.taylorism[id] = validateItem(rawTaylor[id], true));
  return safeLog;
};

const calculateMetrics = (logs: Phase1AuditLogs): Phase2Validation => {
  let adaptCount = 0; let adaptSum = 0; const adaptNOKs: string[] = [];
  let taylorCount = 0; let taylorSum = 0; const taylorNOKs: string[] = [];
  let validItemsFound = 0;
  const silentAreas: string[] = [];
  const categoryScores: Record<string, number> = { A: 0, B: 0, C: 0, D: 0, E: 0 };

  Object.entries(logs.adaptability).forEach(([key, rawItem]) => {
    const item = rawItem as AuditItem;
    if (item.count !== -1) validItemsFound++;
    adaptSum += Math.max(item.count, 0); 
    if (item.status === 'OK') adaptCount++;
    const catPrefix = key.charAt(0);
    if (categoryScores[catPrefix] !== undefined) categoryScores[catPrefix] += Math.max(item.count, 0);
    if (item.count === 0) { silentAreas.push(`Missing Capability: ${key}`); adaptNOKs.push(`[${key}] Missing: ${item.reasoning}`); } 
  });

  Object.entries(logs.taylorism).forEach(([key, rawItem]) => {
    const item = rawItem as AuditItem;
    if (item.count !== -1) validItemsFound++;
    taylorSum += Math.max(item.count, 0);
    if (item.status === 'NOK') taylorCount++;
    if (item.count > 0) { taylorNOKs.push(`[${key}] Constraint: ${item.evidence.substring(0, 100)}...`); }
  });

  const coverageRatio = validItemsFound / 50; 
  const signalStrength = Math.round(coverageRatio * 100);

  const metrics: Metrics = {
    adaptability_ratio: (adaptCount / 25) * 100, 
    taylorism_ratio: (taylorCount / 25) * 100, 
    adaptability_potential: (adaptSum / 75) * 100, 
    taylorism_inertia: (taylorSum / 75) * 100, 
    modernization_readiness: ((adaptSum + (75 - taylorSum)) / 150) * 100, 
    signal_strength: signalStrength
  };

  return { 
      metrics, 
      raw_counts: { adaptability_sub_criteria_met: adaptSum, taylorism_sub_criteria_met: taylorSum }, 
      key_blockers: adaptNOKs, 
      friction_points: taylorNOKs, 
      silent_areas: silentAreas, 
      category_scores: categoryScores 
  };
};

const SIGNAL_THRESHOLD = 85; 

export const analyzeDocument = async (text: string, onProgress: (stage: 'audit' | 'calc' | 'strategy', progress?: number) => void): Promise<DiagnosticResult> => {
  try {
    console.log("Running Security Pre-Flight (DLP)...");
    onProgress('audit', 1);
    const dlpPrompt = generateSafetyAuditPrompt(text);
    
    // UPDATED: Use callHybridGenerate
    const dlpResponse = await callHybridGenerate('gemini-3-flash-preview', [{ role: 'user', parts: [{ text: dlpPrompt }] }]);
    const dlpResult = parseAiResponse(dlpResponse.text);

    if (dlpResult && dlpResult.safe === false) {
        throw new Error(`Security Alert: Document rejected due to ${dlpResult.risk_detected} content. (${dlpResult.reason})`);
    }
    console.log("DLP Scan Passed.");

    console.log("Pre-fetching Knowledge Base for Phase 3...");
    const tacticsPromise = knowledgeBaseService.fetchStrategicPlaybook();

    onProgress('audit', 5); 
    console.log("Calling Orchestrator for Phase 1...");
    const aggregatedRawData = await runPhase1Audit(text, (completed, total) => {
        onProgress('audit', Math.round((completed / total) * 100));
    });
    
    const auditLogs = validateAndSanitizeLogs(aggregatedRawData);

    onProgress('calc', 0);
    await new Promise(r => setTimeout(r, 600));
    onProgress('calc', 100);
    const validationData = calculateMetrics(auditLogs);

    if (validationData.metrics.signal_strength < SIGNAL_THRESHOLD) {
        onProgress('strategy', 100);
        return {
            meta: { document_analyzed: "Uploaded Text", timestamp: new Date().toISOString() },
            phase_1_audit_logs: auditLogs,
            phase_2_validation: validationData,
            phase_3_strategy: {
              executive_summary: `⚠️ **ANALYSIS ABORTED: LOW DATA INTEGRITY**\n\nSignal Strength ${Math.round(validationData.metrics.signal_strength)}% < ${SIGNAL_THRESHOLD}%. The AI could not verify enough criteria to form a safe strategy.`,
              visual_scorecard: { headline: "Audit Inconclusive", readiness_score: "N/A", inertia_score: "N/A" },
              remediation_roadmap: []
            }
        };
    }

    onProgress('strategy', 20);
    const tacticsContext = await tacticsPromise; 
    
    const definitionsContext = JSON.stringify(BATCH_DEFINITIONS, null, 2);
    const fullSSOT = `=== PART 1: THE CRITERIA (DEFINITIONS) ===\n${definitionsContext}\n\n=== PART 2: THE PLAYBOOK (SOLUTIONS) ===\n${tacticsContext}`;

    onProgress('strategy', 50);

    const handoffSummary = `
DIAGNOSTIC REPORT SUMMARY (Computed by System):
------------------------------------------------
Adaptability Readiness: ${Math.round(validationData.metrics.modernization_readiness)}/100
Rigidity (Inertia): ${Math.round(validationData.metrics.taylorism_inertia)}%
Taylorism Constraints Found: ${validationData.friction_points.length}
Adaptability Gaps Found: ${validationData.key_blockers.length}
`;

    // UPDATED: Use callHybridGenerate
    const strategyResponse = await callHybridGenerate(
        "gemini-3-pro-preview", 
        [
            { 
                role: "user", 
                parts: [
                    { text: STRATEGY_USER_PROMPT }, 
                    { text: `\n\n### 🛡️ THE GOLDEN STANDARD (SSOT) 🛡️\nYou must ignore generic internet advice. You may ONLY prescribe solutions found in this Knowledge Base:\n\n${fullSSOT}` }, 
                    { text: `\n\n### 🔍 DIAGNOSTIC FINDINGS (Phase 1 & 2)\nUse these specific blockers to trigger the strategies above:\n${handoffSummary}` },
                    { text: `\n\n### 📄 ORIGINAL SOURCE CONTEXT\n${text}` } 
                ] 
            }
        ],
        STRATEGY_SYSTEM_INSTRUCTION
    );

    onProgress('strategy', 100);
    const strategyData = parseAiResponse(strategyResponse.text);

    return {
      meta: { document_analyzed: "Uploaded Text", timestamp: new Date().toISOString() },
      phase_1_audit_logs: auditLogs,
      phase_2_validation: validationData,
      phase_3_strategy: strategyData.phase_3_strategy || { executive_summary: "Strategy incomplete.", visual_scorecard: { headline: "Error", readiness_score: "N/A", inertia_score: "N/A" }, remediation_roadmap: [] }
    };

  } catch (error) {
    console.error("Gemini Pipeline Error:", error);
    throw error;
  }
};
    