
import DOMPurify from 'dompurify';

/**
 * 1. FORENSIC SANITIZATION
 * Uses DOMPurify to strip XSS vectors from imported HTML reports.
 * This is critical because users might share reports, and we cannot trust the input.
 */
export const forensicSanitizeImport = (dirtyHtml: string): string => {
    return DOMPurify.sanitize(dirtyHtml, {
        USE_PROFILES: { html: true },
        FORBID_TAGS: ['script', 'style', 'iframe', 'object', 'embed', 'form', 'input', 'button'],
        FORBID_ATTR: ['style', 'onmouseover', 'onclick', 'onerror', 'onload']
    });
};

/**
 * 2. AI SAFETY AUDIT (PII & RELEVANCE CHECK)
 * Instead of just keywords, we use a cheap AI model (Flash) to scan for 
 * PII, Secrets, or Non-Business content before the main audit runs.
 */
export const generateSafetyAuditPrompt = (textSample: string) => `
<task>
You are a **Data Loss Prevention (DLP) Officer**.
Scan the following text sample (first 1000 chars) for High-Risk Content.

**HIGH-RISK CATEGORIES:**
1. **PII:** Social Security Numbers, Passport Numbers, Home Addresses.
2. **SECRETS:** API Keys, AWS Credentials, Private Keys, Passwords.
3. **IRRELEVANCE:** Cooking recipes, fiction, fanfiction, or gibberish.

**OUTPUT FORMAT:**
Return a JSON object ONLY:
{
  "safe": boolean,
  "risk_detected": "None" | "PII" | "Secrets" | "Irrelevant",
  "reason": "Short explanation"
}
</task>

<text_sample>
${textSample.substring(0, 1000)}...
</text_sample>
`;

/**
 * 3. METADATA VALIDATOR
 * Ensures that saved simulation data contains only text, no binary blobs.
 */
export const validateMetadataPayload = (payload: any): boolean => {
    if (!payload) return false;
    // Check size (Prevent large payload attacks)
    const size = new TextEncoder().encode(JSON.stringify(payload)).length;
    if (size > 500000) return false; // Max 500KB for metadata

    // Ensure strict schema (Text Only)
    const validKeys = ['meta', 'phase_1_audit_logs', 'phase_2_validation', 'phase_3_strategy'];
    const hasKeys = validKeys.every(k => k in payload);
    
    return hasKeys;
};
