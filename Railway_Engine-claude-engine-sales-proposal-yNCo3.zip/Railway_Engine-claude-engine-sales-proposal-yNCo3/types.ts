
export interface AuditItem {
  count: number;
  status: "OK" | "Partial" | "NOK";
  evidence: string;
  reasoning?: string; // NEW: Captures the "Why" from the AI
  is_silent?: boolean; // New flag for "Ghost Mode"
}

export interface AuditCategory {
  [key: string]: AuditItem;
}

export interface Phase1AuditLogs {
  adaptability: AuditCategory;
  taylorism: AuditCategory;
}

export interface Metrics {
  adaptability_ratio: number;
  taylorism_ratio: number;
  adaptability_potential: number;
  taylorism_inertia: number;
  modernization_readiness: number;
  signal_strength: number; // NEW: Percentage of non-silent items
}

export interface RawCounts {
  adaptability_sub_criteria_met: number;
  taylorism_sub_criteria_met: number;
}

export interface Phase2Validation {
  metrics: Metrics;
  raw_counts: RawCounts;
  key_blockers: string[];
  friction_points: string[];
  silent_areas: string[]; // NEW: List of areas with no data
  category_scores: Record<string, number>; // NEW: Breakdown for strategy generation
}

export interface RemediationStep {
  phase: string;
  actions: string[];
}

export interface VisualScorecard {
  headline: string;
  readiness_score: string;
  inertia_score: string;
}

export interface Phase3Strategy {
  executive_summary: string;
  visual_scorecard: VisualScorecard;
  remediation_roadmap: RemediationStep[];
}

export interface AnalysisMeta {
  document_analyzed: string;
  timestamp: string;
}

export interface DiagnosticResult {
  meta: AnalysisMeta;
  phase_1_audit_logs: Phase1AuditLogs;
  phase_2_validation: Phase2Validation;
  phase_3_strategy: Phase3Strategy;
}

// NEW: Pre-Flight Scan Types
export interface ScanResult {
    score: number; // 0-100
    status: 'Ready' | 'Weak' | 'Insufficient';
    message: string;
    details: string[];
    canRun: boolean;
}