
// api/upload.js
// ------------------------------------------------------------------
// SECURITY ENFORCEMENT ENDPOINT
// ------------------------------------------------------------------
// This endpoint exists solely to return 403 Forbidden.
// It serves as an architectural guarantee that the application
// is NOT configured to accept file uploads to the server.
// All file parsing happens client-side in the browser.

export const config = {
  api: {
    bodyParser: false, // Disable body parsing to reject payloads immediately
  },
};

export default function handler(req, res) {
  return res.status(403).json({ 
    error: "Forbidden",
    message: "Server-side file upload is strictly disabled. Use client-side parsing." 
  });
}
