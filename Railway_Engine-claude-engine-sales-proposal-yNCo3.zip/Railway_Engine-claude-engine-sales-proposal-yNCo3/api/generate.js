
// api/generate.js

// ✅ VERCEL PRO CONFIG: 10 Minute Timeout (Matches Project Settings)
export const config = {
  maxDuration: 600,
};

export default async function handler(req, res) {
  // 1. DYNAMIC ORIGIN CHECK (CORS)
  const origin = req.headers.origin;
  const isVercel = origin && origin.includes('.vercel.app');
  const isLocal = origin && origin.includes('localhost');

  if (isVercel || isLocal) {
    res.setHeader('Access-Control-Allow-Origin', origin);
  }
  
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(204).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  // 3. API KEY RESOLUTION (CRITICAL FIX)
  // Support 'VITE_API_KEY' because that is what is configured in Vercel
  const apiKey = process.env.API_KEY || process.env.VITE_API_KEY;
  
  if (!apiKey) {
    console.error("Server Error: API_KEY/VITE_API_KEY is missing in Vercel Environment Variables.");
    return res.status(500).json({ error: "Server Configuration Error: API_KEY is missing." });
  }

  try {
    const { model, contents, systemInstruction } = req.body || {};

    const payload = {
      contents: contents,
      generationConfig: {
        responseMimeType: "application/json"
      }
    };

    if (systemInstruction) {
      payload.systemInstruction = {
        parts: [{ text: typeof systemInstruction === 'string' ? systemInstruction : JSON.stringify(systemInstruction) }]
      };
    }

    // Default to gemini-3-flash-preview if not specified
    const modelName = model || 'gemini-3-flash-preview';
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${apiKey}`;

    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Gemini API Error:", errorText);
      return res.status(response.status).json({ error: `Gemini API Error: ${errorText}` });
    }

    const data = await response.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "{}";

    return res.status(200).json({ text });

  } catch (error) {
    console.error("Proxy Error:", error);
    return res.status(500).json({ error: error.message || "Internal Proxy Error" });
  }
}
