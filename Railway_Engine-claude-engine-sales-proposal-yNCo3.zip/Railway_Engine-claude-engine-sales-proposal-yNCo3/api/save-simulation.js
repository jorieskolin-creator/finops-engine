
// api/save-simulation.js
// ------------------------------------------------------------------
// METADATA SYNC ENDPOINT
// ------------------------------------------------------------------
// This endpoint accepts text-based analysis results (Metadata) only.
// It strictly rejects binary data or raw PDF content.

export default async function handler(req, res) {
  // 1. Method Check
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  try {
    const payload = req.body;

    // 2. Payload Validation (Lite DLP)
    // Ensure we aren't accidentally saving raw file buffers
    const payloadString = JSON.stringify(payload);
    
    // Check for common binary markers in JSON or excessive size
    if (payloadString.length > 2000000) { // 2MB Limit
        return res.status(413).json({ error: "Payload too large. Metadata only." });
    }

    // 3. Stub Database Logic
    // In a real deployment, this would save to Postgres/Supabase.
    // We do NOT log the payload or filename to Vercel logs to ensure Zero-Retention.
    
    return res.status(200).json({ 
        status: "saved", 
        id: "sim_" + Date.now(),
        message: "Metadata synced successfully." 
    });

  } catch (error) {
    console.error("Save Error:", error);
    return res.status(500).json({ error: "Internal Error" });
  }
}
