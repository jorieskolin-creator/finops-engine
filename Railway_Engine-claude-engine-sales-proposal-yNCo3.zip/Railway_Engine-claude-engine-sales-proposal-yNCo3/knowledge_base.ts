
// 1. STRATEGIC TACTIC INTERFACE
export interface StrategicTactic {
    id: string;
    category: 'Structure' | 'Flow' | 'Governance' | 'Innovation' | 'Leadership';
    problem_pattern: string;
    solution_mechanism: string;
    case_study: string; 
    resource_label?: string; 
    resource_url?: string;   
}

// 2. FALLBACK TACTICS (Used only if network fails completely)
const FALLBACK_TACTICS: StrategicTactic[] = [
    {
        id: "TAC-FALLBACK",
        category: "Structure",
        problem_pattern: "Functional Silos",
        solution_mechanism: "Service-Based Architecture",
        case_study: "AMAZON: API Mandate decoupled teams."
    }
];

// 3. MASTER BINGO MATERIAL (The Detection Library)
export const MASTER_BINGO = {
    taylorism: [
        { id: "T01", title: "Substantive Rationality", desc: "The epistemological error of believing complex future states can be calculated a priori." },
        { id: "T02", title: "Prediction Gap", desc: "The divergence between a pre-designed plan and the evolved reality of the market." },
        { id: "T03", title: "The Ivory Tower", desc: "Centralized decision-making structures detached from the 'Edge' where value is created." },
        { id: "T04", title: "Analysis Paralysis", desc: "The state of over-analyzing data to find a perfect solution, halting action and learning." },
        { id: "T05", title: "Deterministic Planning", desc: "Assuming a linear cause-and-effect relationship in complex adaptive systems." },
        { id: "T06", title: "Big Upfront Design (BUFD)", desc: "Attempting to define all requirements and specifications before a single line of code or value is created." },
        { id: "T07", title: "Gantt Chart Fetishism", desc: "Believing that a visual timeline equals reality; prioritizing the maintenance of the chart over the delivery of the work." },
        { id: "T08", title: "Management by Exception", desc: "A style where management only intervenes when deviations occur, encouraging workers to hide problems." },
        { id: "T09", title: "Iron Triangle Rigidity", desc: "The refusal to trade off Scope, Time, or Cost, leading to quality degradation." },
        { id: "T10", title: "Five-Year Roadmaps", desc: "Detailed long-term plans in volatile markets that serve as 'fantasy documents'." },
        { id: "T11", title: "The Efficiency Trap", desc: "A systemic failure mode where an organization optimizes 'doing things right' to the point of losing relevance." },
        { id: "T12", title: "Resource Efficiency", desc: "The metric of 'Utilization' (keeping people busy), which creates queues and destroys flow." },
        { id: "T13", title: "Total Cost of Ownership (TCO)", desc: "A defensive financial metric that views enabling functions (IT, HR) as liabilities to be minimized." },
        { id: "T14", title: "Watermelon Reporting", desc: "Status reports that are 'Green' on the outside (on time/budget) but 'Red' on the inside (delivering no value)." },
        { id: "T15", title: "Velocity Obsession", desc: "Weaponizing agile metrics (e.g., story points) to demand increased output speed regardless of quality." },
        { id: "T16", title: "Vanity Metrics", desc: "Measuring things that look good (e.g., lines of code, hours logged) but do not correlate to customer outcomes." },
        { id: "T17", title: "Cost Center Mentality", desc: "Viewing teams solely as expenses to be cut rather than assets that generate value." },
        { id: "T18", title: "Individual Performance KPIs", desc: "Metrics that pit team members against each other (e.g., 'bugs fixed per developer')." },
        { id: "T19", title: "Utilization Optimization", desc: "The drive to ensure every worker is 100% booked, eliminating the 'slack' necessary for responsiveness." },
        { id: "T20", title: "Shadow Accounting", desc: "Detailed internal tracking of hours/dollars between departments that generates zero value." },
        { id: "T21", title: "Digital Taylorism", desc: "The application of scientific management to knowledge work, using technology to standardize/de-skill tasks." },
        { id: "T22", title: "Algorithmic Management", desc: "The use of algorithms to assign tasks ('Push'), stripping workers of autonomy." },
        { id: "T23", title: "De-skilling", desc: "The intentional fragmentation of roles to reduce reliance on individual competence." },
        { id: "T24", title: "Cognitive Monoculture", desc: "The loss of diverse thinking resulting from standardized processes." },
        { id: "T25", title: "The Tool Trap", desc: "Adopting Agile tools (Jira, Slack) without changing the underlying mindset ('Fake Agile')." },
        { id: "T26", title: "Electronic Panopticon", desc: "The use of digital surveillance (keystroke logging) to enforce compliance." },
        { id: "T27", title: "Scripted Interactions", desc: "Forcing support or sales staff to follow rigid scripts, preventing empathy." },
        { id: "T28", title: "Ticket Milling", desc: "Reducing complex problem-solving to closing tickets as fast as possible." },
        { id: "T29", title: "Human Middleware", desc: "Using people to manually bridge the gap between disconnected systems (data-entry robots)." },
        { id: "T30", title: "Precariatization", desc: "Treating the workforce as interchangeable, on-demand 'gigs' with no security." },
        { id: "T31", title: "Functional Silos", desc: "The segmentation of expertise by skill set, necessitating hand-offs." },
        { id: "T32", title: "Hand-offs", desc: "The transfer of work between silos, serving as the primary source of friction." },
        { id: "T33", title: "Bureaucratic Latency", desc: "The time delay introduced by governance gates and approval hierarchies." },
        { id: "T34", title: "Command and Control", desc: "The industrial hierarchy where information flows up and orders flow down." },
        { id: "T35", title: "Standard Operative Output", desc: "The focus on producing tasks/deliverables rather than realizing customer value." },
        { id: "T36", title: "HIPPO Decision Making", desc: "Decisions based on the 'Highest Paid Person's Opinion' rather than data." },
        { id: "T37", title: "Information Hoarding", desc: "Using information as a currency of power rather than sharing it transparently." },
        { id: "T38", title: "Gatekeeping", desc: "Processes designed to stop work from proceeding until arbitrary criteria are checked." },
        { id: "T39", title: "Change Control Boards (CCB)", desc: "Bureaucratic committees that review changes far from the context." },
        { id: "T40", title: "Proxy Wars", desc: "When Product Owners or Managers act as barriers between the developers and the actual customers." },
        { id: "T41", title: "Zero Tolerance for Failure", desc: "A culture where variance is punished, leading to risk aversion." },
        { id: "T42", title: "Ad-Hoc Interventions", desc: "Decision-making driven by emergency management overrides rather than a rhythmic model." },
        { id: "T43", title: "Root Cause Blame", desc: "Attributing systemic failures to 'Human Error' rather than bad design." },
        { id: "T44", title: "Learned Helplessness", desc: "A state where teams stop suggesting improvements because they believe nothing will ever change." },
        { id: "T45", title: "Compliance over Competence", desc: "Valuing adherence to the rulebook more than the ability to solve the problem." },
        { id: "T46", title: "Hero Culture", desc: "Relying on individuals to work unsustainable hours to save the day." },
        { id: "T47", title: "Psychological Danger", desc: "An environment where asking questions or admitting mistakes is viewed as weakness." },
        { id: "T48", title: "Gold Plating", desc: "Adding unnecessary features or polish out of fear that the 'MVP' will be judged as failure." },
        { id: "T49", title: "Cover Your Ass (CYA)", desc: "Documentation created solely to defend against future blame." },
        { id: "T50", title: "Weaponized Transparency", desc: "Using 'openness' (e.g., public bug lists) to shame individuals." }
    ],
    adaptability: [
        { id: "A01", title: "Service Areas", desc: "Cross-functional units organized around value streams, possessing all skills to deliver end-to-end." },
        { id: "A02", title: "Podular Organization", desc: "A modular structure of autonomous units that can be reconfigured dynamically." },
        { id: "A03", title: "Architectural Isomorphism", desc: "The alignment of business structure and technical architecture (Conway’s Law)." },
        { id: "A04", title: "Zero Distance", desc: "The elimination of intermediaries between the value creator and the customer." },
        { id: "A05", title: "Microservices/Squads", desc: "The technical/organizational equivalent of independent components released asynchronously." },
        { id: "A06", title: "Inverse Conway Maneuver", desc: "Deliberately designing the team structure to force the desired software architecture." },
        { id: "A07", title: "Dynamic Reteaming", desc: "The ability for teams to split, merge, or change composition without bureaucratic friction." },
        { id: "A08", title: "Fractal Scale", desc: "Structures that look the same at different levels of magnification." },
        { id: "A09", title: "Fluid Hierarchy", desc: "Leadership that shifts based on context and expertise rather than fixed job titles." },
        { id: "A10", title: "Network of Teams", desc: "A mental model where the organization is a mesh of nodes, not a pyramid." },
        { id: "A11", title: "Flow Efficiency", desc: "The primary metric of the fluid state: the speed of value traversal (Work time / Lead time)." },
        { id: "A12", title: "Outcome Metrics", desc: "Measuring success by value realized (e.g., 'Safe Home') vs. deliverables (e.g., 'Hammer')." },
        { id: "A13", title: "Total Value of Ownership (TVO)", desc: "Assessing enablers by their contribution to growth/speed rather than just cost." },
        { id: "A14", title: "Internal Market", desc: "A system where teams 'buy' and 'sell' services internally, replacing budget allocation." },
        { id: "A15", title: "Cost of Delay", desc: "Quantifying the economic impact of not delivering value right now to prioritize work." },
        { id: "A16", title: "Leading Indicators", desc: "Metrics that predict future success (e.g., customer engagement) rather than lagging indicators." },
        { id: "A17", title: "Throughput Accounting", desc: "Financial management focused on the rate at which the system generates money through sales." },
        { id: "A18", title: "Work in Process (WIP) Limits", desc: "Constraints placed on active work to force focus and expose bottlenecks." },
        { id: "A19", title: "Cycle Time", desc: "The time it takes to complete a single unit of work from start to finish." },
        { id: "A20", title: "Value Stream Mapping", desc: "Visualizing the end-to-end flow to identify and remove waste/wait states." },
        { id: "A21", title: "Wicked Problems", desc: "Acknowledging challenges with fluid definitions that resist linear resolution." },
        { id: "A22", title: "Procedural Rationality", desc: "Designing processes to discover solutions rather than calculating them." },
        { id: "A23", title: "Self-Expression Values", desc: "The societal shift toward autonomy driving the need for new management models." },
        { id: "A24", title: "Psychological Safety", desc: "Reframing failure as learning to enable risk-taking." },
        { id: "A25", title: "Cognitive Diversity", desc: "Leveraging varied perspectives to solve non-linear problems." },
        { id: "A26", title: "Horizontal Transparency", desc: "Making performance data visible to peers to drive self-regulation." },
        { id: "A27", title: "Growth Mindset", desc: "The belief that intelligence and abilities can be developed." },
        { id: "A28", title: "Generative Culture", desc: "A performance-oriented culture where information flows freely." },
        { id: "A29", title: "Radical Candor", desc: "Caring personally while challenging directly; feedback is specific and sincere." },
        { id: "A30", title: "Communities of Practice (CoP)", desc: "Voluntary groups where people connect around a shared skill across silos." },
        { id: "A31", title: "Explorative vs. Exploitative", desc: "The distinction between unpredictable innovation (Path B) and predictable optimization (Path A)." },
        { id: "A32", title: "Sense-and-Respond", desc: "A strategic loop of continuous scanning and adjustment." },
        { id: "A33", title: "Launch-and-Learn", desc: "An iterative methodology treating releases as hypotheses." },
        { id: "A34", title: "Transient Optimization", desc: "Accepting that solutions are never 'finished,' only 'good enough' for now." },
        { id: "A35", title: "Probabilistic Forecasting", desc: "Using ranges/probabilities (Monte Carlo) for planning rather than deterministic Gantt charts." },
        { id: "A36", title: "Anti-Fragile", desc: "Systems designed to get stronger/better when subjected to shock and stress." },
        { id: "A37", title: "Mission Command", desc: "Leadership defines the 'What' and 'Why' (Intent), leaving the 'How' to the teams." },
        { id: "A38", title: "Real Options", desc: "Deferring decisions to the 'last responsible moment' to keep options open." },
        { id: "A39", title: "Rolling Wave Planning", desc: "Planning in detail for the near term and in outline for the long term." },
        { id: "A40", title: "Betting Strategy", desc: "Viewing initiatives as 'bets' with defined loss thresholds rather than 'projects'." },
        { id: "A41", title: "Opportunity Platform", desc: "A routing engine that categorizes demand into 'Standard' or 'Iterative' paths." },
        { id: "A42", title: "Enabling Platforms", desc: "Tech layers that provide shared services (HR, IT) as 'Pull-based' products." },
        { id: "A43", title: "API Mandate", desc: "The requirement to expose data/functionality via interfaces to enforce decoupling." },
        { id: "A44", title: "Shared Leadership", desc: "Leaders provide 'Why/Context'; teams provide 'What/How'." },
        { id: "A45", title: "Pull-Based Teaming", desc: "Individuals self-select work based on skills ('Freedom to Choose')." },
        { id: "A46", title: "Context, Not Control", desc: "Setting broad strategic parameters while allowing tactical autonomy." },
        { id: "A47", title: "Competence-Driven Resourcing", desc: "Assigning people based on specific skills not job titles." },
        { id: "A48", title: "Dynamic Funding", desc: "'The Bank is Always Open'—venture-style funding for internal initiatives." },
        { id: "A49", title: "T-Shaped Skills", desc: "Individuals with deep expertise in one area and broad ability to collaborate." },
        { id: "A50", title: "Chaos Engineering", desc: "Intentionally introducing turbulence to test and build system resilience." }
    ]
};

// 4. SHARED GUARDRAILS (Used in Prompts)
export const SHARED_GUARDRAILS = `
<task>
You are a **Forensic Auditor**. Your job is to extract **explicit proof** from the text.
**CRITICAL:** You must NOT give the "benefit of the doubt". You are looking for Traceable Evidence.

For EVERY item in the provided Knowledge Base, you must determine **Signal Strength (Count)**:

**SCALE:**
*   **0 (Absent):** No evidence found.
    *   *Stream A:* This is **BAD** (Missing Capability).
    *   *Stream B:* This is **GOOD** (Clean/Healthy).
*   **1 (Weak):** Buzzwords or vague intent only.
*   **2 (Clear):** Behavior is described.
*   **3 (Strong):** Explicit mechanisms, rules, or enforcement.
    *   *Stream A:* This is **GOOD** (Mature Capability).
    *   *Stream B:* This is **BAD** (Rigid Constraint).

**RULES OF EVIDENCE (THE "CLEAN ROOM" PROTOCOL):**
1. **Source of Truth:** You must **ONLY** extract evidence from the XML tag <UNTRUSTED_CONTENT>. 
2. **No Inference:** If the text says "We plan to become agile", that is NOT evidence of "Agile Maturity". It is evidence of *intent* only (Score 1).
3. **Stream B Specifics:** 
   - You are looking for **EVIDENCE OF RIGIDITY**.
   - If you find "Approvals", "Silos", or "Command & Control" -> **Score 3**.
   - If the text is silent on these bad habits -> **Score 0**.

</task>

<output_format>
STRICTLY return a JSON object. Do not include any text outside the JSON.
**IMPORTANT**: You must analyze ALL 10 items in this batch. Do not skip items.
If an item has score 0, you must still provide the reasoning why (e.g., "Document was silent").

**STEP-BY-STEP FORMATTING**:
For every item you find, you MUST include a "reasoning" field BEFORE the score.
This reasoning field is your "scratchpad" to prove the connection between the text and the criterion.
</output_format>
`;

// 5. BATCH DEFINITIONS (The SSOT - Fully Populated from Master Material)
export const BATCH_DEFINITIONS = {
  A: {
    title: "Structural Foundation",
    adaptability: `
        <item id="A1">
            <title>Prioritize Efficacy ("Doing the Right Things") over Efficiency</title>
            <description>
            The organization must distinguish between "Efficiency" (doing things right/fast) and "Efficacy" (doing the right things). It must avoid the "Efficiency Trap," where standardized perfection hinders adaptability. The focus must be on Impact and Value Creation, accepting that "flow efficiency" (speed of value) is more important than "resource efficiency" (busyness of people).
            </description>
            <criteria>
            1. Does the organization's strategic reporting weigh "Outcome Metrics" (Impact/Revenue Growth) significantly higher than "Output Metrics" (Speed/Volume/Utilization)?
            2. Is there a governance mechanism (like the Impact Opportunity Platform) that actively stops "efficient" projects if they fail to demonstrate continued strategic efficacy?
            3. Does the organization explicitly accept lower resource utilization rates (slack) to ensure capacity for sensing, learning, and identifying the "Right Things"?
            </criteria>
        </item>
        <item id="A2">
            <title>Expertise Organized as Service Areas</title>
            <description>
            Expertise must be organized around value creation as "Service Areas" or "Value Streams", not as functional silos (e.g., IT, Sales, Marketing). These Service Areas must possess all necessary cross-functional skills to deliver value end-to-end to the customer, eliminating hand-offs.
            </description>
            <criteria>
            1. Have functional silos been reorganized into "Service Areas" that possess all cross-functional skills necessary to deliver value end-to-end?
            2. Do these Service Areas operate with full autonomy regarding their technical and operational decisions, eliminating the need for hand-offs to external departments?
            3. Is funding and resourcing allocated to these continuous Service Areas ("Product-based") rather than to temporary projects or functional cost centers?
            </criteria>
        </item>
        <item id="A3">
            <title>Operating Rhythm with Defined Inputs/Outputs</title>
            <description>
            The organization must maintain a rigorous "Operating Rhythm" that synchronizes decision-making. This rhythm must have clearly defined inputs (market signals, insights) and outputs (decisions, pivots) to enable a "Sense-and-Respond" loop without needing external approvals.
            </description>
            <criteria>
            1. Does the organization have a standardized "Operating Rhythm" that synchronizes decision-making without relying on ad-hoc meetings?
            2. Are the "Inputs" (e.g., market signals) and "Outputs" (e.g., strategic pivots) of every governance interaction explicitly defined?
            3. Does this rhythm enable a "Sense-and-Respond" loop that triggers immediate strategic redirection inside the Service Area without external approvals?
            </criteria>
        </item>
        <item id="A4">
            <title>Enabling Functions as Value Enablers (TVO)</title>
            <description>
            Enabling functions (IT, HR, Finance) must be viewed as "Enablers" or Platform Teams that provide "Pull-based shared services". Their value is measured by Total Value of Ownership (TVO) and their contribution to growth and ROCE (Return on Capital Employed), rather than minimized via Total Cost of Ownership (TCO).
            </description>
            <criteria>
            1. Are enabling functions managed as "Value Enablers" with metrics tied to growth/ROCE rather than cost minimization?
            2. Does the organization calculate "Total Value of Ownership" (TVO) for enabling technologies, factoring in innovation and speed, rather than just "Total Cost of Ownership" (TCO)?
            3. Is the acceleration of "Idea-to-Value" time tracked as the primary performance indicator for these enabling functions?
            </criteria>
        </item>
        <item id="A5">
            <title>Logic for Explorative vs. Exploitative Work</title>
            <description>
            The organization must have a clear logic to distinguish between "Standardized" (Exploitative/Predictable) work and "Iterative" (Explorative/Unpredictable) work. Different management logics, capacity planning, and team structures must be applied to each to avoid the "Efficiency Trap".
            </description>
            <criteria>
            1. Is there a formal logic to categorize demand into "Explorative" (Iterative/Unpredictable) versus "Exploitative" (Standard/Predictable) paths?
            2. Are distinct capacity planning models applied to these streams (e.g., Resource Pools for standard vs. Dedicated/Self-Organizing Teams for exploration)?
            3. Does the execution model prevent "Efficiency" metrics from being applied to "Explorative" work?
            </criteria>
        </item>`,
    taylorism: `
        <item id="A1">
            <title>Prioritize Efficiency ("Doing Things Fast") over Efficacy</title>
            <description>
            The organization falls into the "Efficiency Trap," prioritizing "Resource Efficiency" (minimizing waste/idle time) above all else. It assumes that if every component works faster/cheaper, the whole system improves. Effectiveness (Impact) is sacrificed for the appearance of speed and cost reduction.
            </description>
            <criteria>
            1. Does the organization’s strategic reporting weigh "Output Metrics" (Volume/Speed/Utilization) significantly higher than "Outcome Metrics" (Revenue/Satisfaction)?
            2. Are projects or initiatives allowed to continue simply because they are "on time and on budget," even if they have lost their strategic relevance?
            3. Does the organization actively eliminate "slack" (idle time), viewing it as waste rather than necessary capacity for responsiveness?
            </criteria>
        </item>
        <item id="A2">
            <title>Expertise Organized as Functional Silos</title>
            <description>
            Expertise is segmented into rigid "Functional Silos" (e.g., The Testing Dept, The Design Dept) based on skill sets. Work is passed between these silos via "hand-offs," creating queues and loss of context. Value cannot flow without crossing departmental boundaries.
            </description>
            <criteria>
            1. Are teams organized by "Function" (Skill) rather than "Service Area" (Value Stream), necessitating hand-offs to deliver value?
            2. Do employees lack the autonomy to complete a customer request end-to-end without submitting a request to another department?
            3. Is funding and resourcing allocated to "Cost Centers" or "Projects" rather than continuous Value Streams?
            </criteria>
        </item>
        <item id="A3">
            <title>Top-Down Command and Ad-Hoc Interventions</title>
            <description>
            Instead of a rhythmic "Sense-and-Respond" loop, decision-making is triggered by "Ad-Hoc Interventions" from management. The hierarchy relies on "Command and Control" where inputs are instructions from above, and outputs are compliance reports.
            </description>
            <criteria>
            1. Does the organization rely on "Emergency Interventions" or ad-hoc management meetings to steer direction rather than a set rhythm?
            2. Are "Inputs" defined as "Instructions from Management" rather than "Signals from the Market"?
            3. Must operational pivots be approved by a hierarchy external to the team, preventing immediate response?
            </criteria>
        </item>
        <item id="A4">
            <title>Enabling Functions as Cost Centers (TCO)</title>
            <description>
            Enabling functions (IT, HR, Finance) are viewed as necessary evils or "Cost Centers" to be minimized. The primary metric is "Total Cost of Ownership" (TCO). Tools and systems are standardized to reduce support costs, even if they hamper the productivity of the value creators.
            </description>
            <criteria>
            1. Are enabling functions (IT, HR) measured primarily by "Cost Minimization" (TCO) rather than contribution to growth (TVO)?
            2. Is the procurement of tools driven by "Lowest Cost" rather than "Highest Velocity/Fit" for the specific team?
            3. Is "Standardization of Tools" enforced to reduce support costs, restricting teams from using fit-for-purpose solutions?
            </criteria>
        </item>
        <item id="A5">
            <title>The Logic of Universal Standardization ("One Best Way")</title>
            <description>
            The organization applies a single "Standardized" logic to all work, refusing to recognize the difference between "Exploitative" (Predictable) and "Explorative" (Unpredictable) domains. It attempts to force-fit iterative innovation into linear, predictable project plans (Waterfall disguised as Agile).
            </description>
            <criteria>
            1. Does the organization apply the same "Efficiency" metrics and planning logic to Innovation work as it does to Routine Operations?
            2. Is "Variance" or "Uncertainty" treated as a failure of planning rather than a natural characteristic of the work?
            3. Are "Resource Pools" used to assign individuals to tasks dynamically, treating them as interchangeable cogs?
            </criteria>
        </item>`
  },
  B: {
    title: "Flow & Strategy",
    adaptability: `
        <item id="B1">
            <title>Focus on Flow Efficiency</title>
            <description>
            The primary operational focus must be "Flow Efficiency" (how fast value moves through the system) rather than "Resource Efficiency" (how busy people are). The organization must actively manage queues and Work in Progress (WIP) to ensure flow.
            </description>
            <criteria>
            1. Is "Flow Efficiency" (active work time / total lead time) the primary operational metric rather than "Resource Utilization"?
            2. Does management actively limit "Work in Progress" (WIP) to ensure value moves, even if it means personnel have idle time?
            3. Are bottlenecks identified based on where work waits, rather than where people are not busy?
            </criteria>
        </item>
        <item id="B2">
            <title>Co-created Strategy Executed Autonomously</title>
            <description>
            Strategy must be co-created involving the Service Areas closest to the customer to ensure alignment with reality. Service Areas must have the autonomy to execute this strategy without constant permission-seeking, aligned via shared "Impact Statements".
            </description>
            <criteria>
            1. Is strategy formulation a co-creative process involving the Service Areas closest to the customer?
            2. Are Service Areas empowered to execute autonomously based on aligned strategic intent (Impact Statements)?
            3. Is there clear alignment of "Impact Statements" across the value stream to prevent fragmentation?
            </criteria>
        </item>
        <item id="B3">
            <title>Systemic Development over Heroics</title>
            <description>
            Problems must be solved by developing the system (architecture, processes, automation) rather than relying on individual "Heroics" or creating new governance layers. The "Impact Opportunity Platform" is the engine for eliminating deep-rooted systemic causes.
            </description>
            <criteria>
            1. When problems arise, is the focus on "Systemic Development" (fixing the process/platform) rather than "Individual Heroics"?
            2. Is the creation of new governance layers actively avoided as a solution to operational problems?
            3. Are "Heroes" viewed as a symptom of a broken system that requires redesign?
            </criteria>
        </item>
        <item id="B4">
            <title>Pull-Based Teaming ("Freedom to Choose")</title>
            <description>
            Teams must form around value creation using a "Pull" principle, where members self-select work based on skills and interest ("Freedom to Choose"). Teams must autonomously design, build, and deliver the solution end-to-end.
            </description>
            <criteria>
            1. Are teams formed using a "Pull" principle where members self-select work ("Freedom to Choose"), rather than being assigned by managers?
            2. Do teams possess full autonomy to design, build, and deliver the solution end-to-end?
            3. Is a platform (like the Impact Opportunity Platform) used to facilitate dynamic teaming based on value demands?
            </criteria>
        </item>
        <item id="B5">
            <title>Competence-Driven Resource Planning</title>
            <description>
            Resource planning must be competence-driven and based on specific skills/ambitions (e.g., using a "Diary Database", "Pull-principle") rather than generic "Role-based" headcount. This allows for "Fit for Purpose" teaming.
            </description>
            <criteria>
            1. Is resource planning based on specific "Competencies" and "Ambitions" rather than generic "Job Roles"?
            2. Does the organization utilize a dynamic mechanism (e.g., Diary Database) to track evolving skills and ambitions?
            3. Are teams assembled based on the synergy of competencies required for the specific "Job-to-be-Done"?
            </criteria>
        </item>`,
    taylorism: `
        <item id="B1">
            <title>Focus on Resource Efficiency (Utilization Obsession)</title>
            <description>
            The primary operational focus is "Resource Efficiency" (keeping people 100% busy). The organization maximizes utilization, which paradoxically ensures that work waits in queues (Low Flow Efficiency). "Busyness" is the proxy for productivity.
            </description>
            <criteria>
            1. Is "Resource Utilization" (hours billed/worked) the primary operational metric rather than "Flow Efficiency" (Lead Time)?
            2. Does management maximize "Work in Progress" (WIP) to ensure no one is ever waiting, resulting in bottlenecks?
            3. Are bottlenecks identified based on "Where people are idle" rather than "Where work is waiting"?
            </criteria>
        </item>
        <item id="B2">
            <title>Strategy Decoupled from Execution (Cascaded)</title>
            <description>
            Strategy is formulated at the top by "Thinkers" and cascaded down to "Doers." There is a strict separation of Conception and Execution. Teams are expected to execute the plan, not challenge or evolve it.
            </description>
            <criteria>
            1. Is strategy formulated exclusively by leadership without the active involvement of the Service Areas closest to the customer?
            2. Are teams required to seek permission to deviate from the strategic plan, even if the plan is visibly failing?
            3. Is alignment achieved via "Compliance" to instructions rather than "Commitment" to shared Impact Statements?
            </criteria>
        </item>
        <item id="B3">
            <title>Individual Heroics and Root Cause Blame</title>
            <description>
            When systems fail, the organization blames individuals ("Human Error"). It relies on "Heroics" (overtime, crunch culture) to meet deadlines, rather than fixing the systemic constraints. Process improvement is reactive, adding more checks/gates after every failure.
            </description>
            <criteria>
            1. When deadlines are missed, is the response "Work Harder/Overtime" (Heroics) rather than "Redesign the System"?
            2. Is "Root Cause Analysis" focused on finding who messed up (Blame) rather than what system failed?
            3. Are governance layers added to "police" behavior rather than platform automation to "enable" it?
            </criteria>
        </item>
        <item id="B4">
            <title>Push-Based Task Assignment (Algorithmic Management)</title>
            <description>
            Work is assigned to individuals by managers or algorithms ("Push" principle). Workers have no "Freedom to Choose" or self-organize. This is the "Gig Economy" model applied internally: tasks appear, and workers execute.
            </description>
            <criteria>
            1. Is work assigned to individuals by managers or algorithms ("Push"), preventing self-selection?
            2. Do teams lack the autonomy to design their own solution, restricted instead to executing a specific "spec"?
            3. Is the concept of "Dynamic Teaming" rejected in favor of static, managed assignments?
            </criteria>
        </item>
        <item id="B5">
            <title>Role-Based Resource Allocation ("Cogs in a Machine")</title>
            <description>
            Resource planning is based on generic "Job Roles" (Headcount/FTEs) rather than specific competencies. People are treated as fungible resources—one "Java Developer" is interchangeable with another.
            </description>
            <criteria>
            1. Is resource planning based on generic "FTEs" and "Job Roles" rather than specific skills and people?
            2. Does the organization lack a mechanism (like a Diary Database) to track individual ambitions/skills, relying instead on job titles?
            3. Are teams assembled based on "Availability" (who is free) rather than "Fit for Purpose" (who is best)?
            </criteria>
        </item>`
  },
  C: {
    title: "Governance",
    adaptability: `
        <item id="C1">
            <title>Collaborative Decisions at the Edge</title>
            <description>
            Decisions must be made collaboratively at the "Edge" (Service Area), as part of value creation, and "near the customer" (Zero Distance). Customers should be active participants in the decision loop.
            </description>
            <criteria>
            1. Are operational decisions made collaboratively at the "Edge" (Service Area), closest to the customer?
            2. Is the customer (or direct representative) actively involved in the value creation decision-making?
            3. Does governance explicitly authorize teams to make decisions without seeking external permission?
            </criteria>
        </item>
        <item id="C2">
            <title>Elimination of Functional Incentives</title>
            <description>
            Functional incentives based on efficiency, velocity, or tasks must be eliminated as they create "deep-seated silos". Incentives must be tied to Shared Outcomes and Impact.
            </description>
            <criteria>
            1. Have functional incentives based on "Efficiency," "Velocity," or "Tasks" been eliminated?
            2. Are performance incentives tied strictly to shared "Outcomes" and "Impact"?
            3. Does the reward system measure the success of the "Service Area" rather than the individual function?
            </criteria>
        </item>
        <item id="C3">
            <title>Decoupling (No Control/Coordination)</title>
            <description>
            The organization must be structured to eliminate the need for heavy control and coordination between functions, which causes inefficiency. The goal is "Independent Value Streams" that minimize dependencies.
            </description>
            <criteria>
            1. Has the organization structured itself to eliminate the need for heavy "Control and Coordination" between functions?
            2. Can Service Areas release value independently without synchronization meetings or approvals?
            3. Is "Dependency Management" replaced by "Dependency Elimination" via autonomous structures?
            </criteria>
        </item>
        <item id="C4">
            <title>Governance Embedded in Platform</title>
            <description>
            Governance must be embedded into the "Operating Model" or "Platform" (e.g., automated checks, guardrails) rather than existing as slow, approval-driven "Gates".
            </description>
            <criteria>
            1. Is governance embedded directly into the "Platform/Operating Model" (automated checks) rather than manual "Gates"?
            2. Has "Approval-Driven Governance" been replaced by "Policy/Guardrail-Driven" automation?
            3. Does the platform automatically prevent non-compliant actions, allowing teams to proceed safely?
            </criteria>
        </item>
        <item id="C5">
            <title>Experimentation and Learning ("Tuition")</title>
            <description>
            "Waste" from experimentation must be valued as necessary "Tuition" for learning and innovation. Failure must be viewed as part of "Shared Learning" and not punished. The "Launch-and-Learn" approach relies on this.
            </description>
            <criteria>
            1. Is the "waste" associated with experimentation explicitly valued as a necessary cost of "Learning"?
            2. Does the organization protect experimentation capacity from efficiency optimization programs?
            3. Are "failed" experiments analyzed for insights rather than punished as mistakes?
            </criteria>
        </item>`,
    taylorism: `
        <item id="C1">
            <title>Centralized Decision Making (The Ivory Tower)</title>
            <description>
            Operational decisions are made by managers or committees far removed from the customer. The "Edge" is disempowered. Information flows up; orders flow down.
            </description>
            <criteria>
            1. Are operational decisions routinely escalated to managers or committees rather than made at the "Edge"?
            2. Is the customer (or direct representative) excluded from the decision-making loop during value creation?
            3. Does governance explicitly forbid teams from making decisions (e.g., budget spend) without external permission?
            </criteria>
        </item>
        <item id="C2">
            <title>Functional and Individual Incentives (Piece-Rate)</title>
            <description>
            Incentives are tied to "Efficiency," "Velocity," or "Individual Task Completion." This creates competition between functions (e.g., Dev vs. Ops) and encourages local optimization at the expense of the whole system.
            </description>
            <criteria>
            1. Are performance incentives tied to "Individual Efficiency" or "Volume" rather than Shared Outcomes?
            2. Do incentives pit functions against each other (e.g., Sales bonus for bookings vs. Delivery penalty for costs)?
            3. Is the reward system focused on the "Individual" rather than the "Team/Service Area"?
            </criteria>
        </item>
        <item id="C3">
            <title>Heavy Control and Coordination (Dependency Management)</title>
            <description>
            The organization accepts high dependencies and manages them through heavy "Control and Coordination" layers (Project Managers, Release Trains). The focus is on managing the dependency, not eliminating it via decoupling.
            </description>
            <criteria>
            1. Does the organization require heavy "Coordination/Synchronization" meetings to manage dependencies between teams?
            2. Are Service Areas unable to release value independently without "Integration Phases" or external approvals?
            3. Is "Dependency Management" the norm, rather than "Dependency Elimination"?
            </criteria>
        </item>
        <item id="C4">
            <title>Governance as Inspection Gates (Permission-Based)</title>
            <description>
            Governance exists as manual "Gates" and "Inspections" at the end of a process. There is no trust; work must be verified by a superior before it can proceed.
            </description>
            <criteria>
            1. Is governance implemented as manual "Approval Gates" (e.g., CAB meetings) rather than automated platform checks?
            2. Does the process rely on "Inspection" at the end rather than "Prevention" during the flow?
            3. Are "Policy/Guardrails" absent, necessitating human permission for every major action?
            </criteria>
        </item>
        <item id="C5">
            <title>Variation as Waste (Zero Tolerance for Failure)</title>
            <description>
            "Waste" is strictly defined as anything not directly producing output. Experimentation, which inherently produces failure, is viewed as waste. The goal is "Standardized Perfection."
            </description>
            <criteria>
            1. Is the "waste" associated with experimentation viewed as "Loss" rather than necessary "Tuition"?
            2. Is experimentation capacity the first thing cut during efficiency drives or budget cuts?
            3. Are "failed" experiments punished or viewed as "Performance Issues"?
            </criteria>
        </item>`
  },
  D: {
    title: "Innovation",
    adaptability: `
        <item id="D1">
            <title>Outside-In Strategy</title>
            <description>
            Strategy must be designed "Outside-In," driven by Innovation and Impact for the customer, not derived from internal demands for efficiency or cost savings.
            </description>
            <criteria>
            1. Is strategy explicitly driven by "Customer Innovation/Impact" rather than internal "Efficiency/Cost Savings"?
            2. Are strategic initiatives validated against "Customer Needs" rather than internal operational requirements?
            3. Does the organization prioritize "Total Value of Ownership" (TVO) over "Total Cost of Ownership" (TCO)?
            </criteria>
        </item>
        <item id="D2">
            <title>Integration of Sales and Delivery (Zero Distance)</title>
            <description>
            Sales and Delivery must be integrated into a "Continuous Value Stream" to ensure "Promises made are promises kept". The principle of "Zero Distance" ensures those making promises are connected to those delivering.
            </description>
            <criteria>
            1. Are Sales and Delivery integrated into a "Continuous Value Stream" rather than operating as hand-off entities?
            2. Is "Zero Distance" applied, ensuring the Service Area making the promise connects to the team keeping it?
            3. Do shared visual tools (e.g., Service Blueprints) map the lifecycle from "Promise" to "Delivery"?
            </criteria>
        </item>
        <item id="D3">
            <title>Innovation Built-in</title>
            <description>
            Innovation must be "Built-in" to the operating model of every team, not treated as a special funnel or requiring committee approval. The "Impact Opportunity Platform" acts as the trigger mechanism.
            </description>
            <criteria>
            1. Is innovation explicitly "Built-in" to the daily operating model of every team, not a separate department?
            2. Can teams initiate experiments via a platform mechanism without committee approval?
            3. Is the distinction between "Run" (Maintenance) and "Change" (Innovation) removed?
            </criteria>
        </item>
        <item id="D4">
            <title>Creating Own Insights</title>
            <description>
            The organization must create its "Own Insights" based on internal data and learning (e.g., via "Diary Database") rather than "Outsourcing Thinking" to external consultants.
            </description>
            <criteria>
            1. Does the organization prioritize creating "Own Insights" based on internal data/learning over buying external generic strategy?
            2. Is there a structural capability (e.g., Insight Creation rhythm) that synthesizes internal data into direction?
            3. Is "Outsourcing Thinking" actively discouraged in favor of building internal strategic muscle?
            </criteria>
        </item>
        <item id="D5">
            <title>Network vs. Hierarchy</title>
            <description>
            The organization must be structured as a "Network of Independent Service Areas" rather than a hierarchy of functional silos. Service Areas interact via defined interfaces (APIs).
            </description>
            <criteria>
            1. Is the organization structured as a "Network of Independent Service Areas" rather than a "Hierarchy of Functional Silos"?
            2. Do Service Areas interact via defined interfaces/contracts (APIs)?
            3. Has power shifted from "Functional Heads" to "Service Area Leads" who own value creation?
            </criteria>
        </item>`,
    taylorism: `
        <item id="D1">
            <title>Inside-Out Strategy (Cost-Driven)</title>
            <description>
            Strategy is driven by internal operational requirements (Cost Savings, Efficiency) rather than Customer Impact. The organization asks "What can we sell?" rather than "What do they need?"
            </description>
            <criteria>
            1. Is strategy driven by "Internal Efficiency/Cost Savings" rather than "Customer Innovation"?
            2. Are initiatives validated against "Operational Requirements" rather than "Customer Needs"?
            3. Does the organization prioritize TCO (Total Cost of Ownership) over TVO (Total Value of Ownership)?
            </criteria>
        </item>
        <item id="D2">
            <title>Separation of Promise and Delivery (The Wall)</title>
            <description>
            Sales (Promise) and Operations (Delivery) are separate silos. Sales sells the dream, then "throws it over the wall" to Delivery, who must deal with the reality. "Zero Distance" is violated.
            </description>
            <criteria>
            1. Are Sales and Delivery operating as separate entities with formal hand-offs?
            2. Is "Zero Distance" violated, with those making promises disconnected from those delivering them?
            3. Do teams lack a shared view (Service Blueprint) of the full lifecycle?
            </criteria>
        </item>
        <item id="D3">
            <title>Innovation as a Separate Department (R&D Silo)</title>
            <description>
            Innovation is treated as a separate "Department," "Lab," or "Funnel." Ordinary teams are expected to "Run" (maintain) and not "Change" (innovate). Thinking is segregated from Doing.
            </description>
            <criteria>
            1. Is innovation treated as a separate department/lab rather than part of the daily work of delivery teams?
            2. Are teams forbidden from initiating experiments without "Steering Committee" approval?
            3. Is there a strict distinction between "Run" (Maintenance) and "Change" (Innovation) teams?
            </criteria>
        </item>
        <item id="D4">
            <title>Outsourced Thinking (Consultant Dependency)</title>
            <description>
            The organization relies on external consultants or generic "Best Practices" to provide strategy. It lacks the mechanism to synthesize its own internal data into unique insights.
            </description>
            <criteria>
            1. Does the organization rely on external consultants for strategy rather than building internal strategic muscle?
            2. Is there a lack of structural capability to synthesize internal data into strategic direction?
            3. Is "Thinking" viewed as a commodity to be purchased rather than a core capability?
            </criteria>
        </item>
        <item id="D5">
            <title>Hierarchy and Chain of Command</title>
            <description>
            The organization is structured as a "Hierarchy of Functional Silos" (Pyramid). Power resides with Functional Heads. Communication must traverse up and down the chain of command, not across the network.
            </description>
            <criteria>
            1. Is the organization structured as a "Hierarchy of Functional Silos" rather than a "Network of Independent Service Areas"?
            2. Do interactions between areas require "Escalation" to managers rather than direct interface calls?
            3. Does power reside with "Functional Heads" rather than "Service Area Leads"?
            </criteria>
        </item>`
  },
  E: {
    title: "Leadership",
    adaptability: `
        <item id="E1">
            <title>Leaders Provide Why/Values</title>
            <description>
            Leaders must practice "Shared Leadership," providing the "Why" (Context) and "Values," while Teams provide the "What" and "How" (Decisions). Micromanagement is a violation of this model.
            </description>
            <criteria>
            1. Do leaders limit their role to providing "Why" (Context) and "Values," delegating "What/How" to teams?
            2. Are teams empowered to make solution decisions without executive intervention if aligned with context?
            3. Is "Micromanagement" identified and eliminated as a violation of Shared Leadership?
            </criteria>
        </item>
        <item id="E2">
            <title>Failure Reframed as Learning</title>
            <description>
            Failure must be reframed as "Evidence-based Learning" and creating a "Psychologically Safe" environment. Failure is not waste; it is the generation of new information.
            </description>
            <criteria>
            1. Is "Failure" explicitly reframed and rewarded as "Learning" rather than punished?
            2. Does the organization practice "Blameless Post-Mortems" to extract insights?
            3. Is "Psychological Safety" actively cultivated to ensure teams feel safe to experiment?
            </criteria>
        </item>
        <item id="E3">
            <title>Metrics Focus on Outcomes</title>
            <description>
            Metrics must focus on "Outcomes" (Customer Value, Impact) rather than "Efficiency" (Cost, Speed) or past financial reports.
            </description>
            <criteria>
            1. Do primary metrics focus on "Outcomes" (Impact/Customer Value) rather than "Efficiency" (Cost/Speed)?
            2. Are "Past Financial Reports" (Lagging Indicators) supplemented by "Leading Indicators" of value creation?
            3. Is success decoupled from "Budget Adherence" and attached to "Value Realization"?
            </criteria>
        </item>
        <item id="E4">
            <title>Probabilistic and Dynamic Capacity Planning</title>
            <description>
            Capacity planning for explorative work must be "Dynamic", "Pull-driven", and use "Probabilistic Forecasting". Rigid allocations of resources must be abandoned.
            </description>
            <criteria>
            1. Is capacity planning for explorative work "Dynamic" and "Pull-driven"?
            2. Has the organization abandoned "Rigid Allocations" (fixed resource locking) for flexible resourcing?
            3. Is "Probabilistic Forecasting" used for uncertain work rather than deterministic deadlines?
            </criteria>
        </item>
        <item id="E5">
            <title>Success as Result ("Safe Home") vs. Deliverable</title>
            <description>
            Success must be measured by the "Result" (e.g., "Safe Home") rather than the "Deliverable" (e.g., "A Hammer"). Requirements must be defined as "Problems to Solve" rather than "Features to Build".
            </description>
            <criteria>
            1. Is success measured by the "Result" (e.g., Safe Home) rather than the "Deliverable" (e.g., A Hammer)?
            2. Are requirements defined as "Problems to Solve" (Outcomes) rather than "Features to Build" (Outputs)?
            3. Does the culture celebrate "Value Realization" over "Task Completion"?
            </criteria>
        </item>`,
    taylorism: `
        <item id="E1">
            <title>Leaders Dictate "How" (Micromanagement)</title>
            <description>
            Leaders practice "Command and Control." They dictate not just the "Why" (Context) but the "What" and the "How." Digital tools are used to monitor compliance and activity ("Digital Panopticon").
            </description>
            <criteria>
            1. Do leaders dictate the "What" and "How" rather than limiting their role to the "Why" (Context)?
            2. Are teams subject to "Micromanagement" or frequent check-ins on task status/busyness?
            3. Is "Shared Leadership" absent, with all authority vested in the manager?
            </criteria>
        </item>
        <item id="E2">
            <title>Failure as Defect (Blame Culture)</title>
            <description>
            Failure is viewed as a defect to be punished, not data to be learned from. The organization lacks "Psychological Safety," leading to hidden errors and "Watermelon Reporting" (Green on the outside, Red on the inside).
            </description>
            <criteria>
            1. Is "Failure" punished or viewed as a performance issue rather than a learning opportunity?
            2. Are "Post-Mortems" focused on assigning blame to individuals?
            3. Is "Psychological Safety" low, preventing teams from admitting mistakes or signaling red status?
            </criteria>
        </item>
        <item id="E3">
            <title>Metrics Focus on Outputs (Volume/Activity)</title>
            <description>
            Metrics focus on "Outputs" (Speed, Cost, Volume, Lines of Code) rather than "Outcomes" (Value, Behavior Change). Management steers by "Lagging Indicators" (Past Financials).
            </description>
            <criteria>
            1. Do primary metrics focus on "Outputs" (Speed/Cost/Volume) rather than "Outcomes" (Value)?
            2. Is success tied to "Budget Adherence" rather than "Value Realization"?
            3. Are "Lagging Indicators" (Financials) the only metrics that drive decision-making?
            </criteria>
        </item>
        <item id="E4">
            <title>Deterministic and Rigid Capacity Planning</title>
            <description>
            Capacity planning is "Deterministic" and "Rigid." Resources are locked into plans months in advance ("Allocated"). The plan is treated as truth; variance is treated as error.
            </description>
            <criteria>
            1. Is capacity planning "Rigid" and "Deterministic" (Fixed Allocations)?
            2. Is "Probabilistic Forecasting" rejected in favor of "Hard Deadlines" and "Gantt Charts"?
            3. Are resources "Locked" to projects, preventing flow to high-value work?
            </criteria>
        </item>
        <item id="E5">
            <title>Success as Deliverable ("The Widget") vs. Result</title>
            <description>
            Success is measured by "Did we ship the feature?" (The Hammer) rather than "Did we solve the problem?" (The Safe Home). Requirements are defined as "Features to Build," creating a "Feature Factory."
            </description>
            <criteria>
            1. Is success measured by the "Deliverable" (Feature/Project completion) rather than the "Result" (Outcome)?
            2. Are requirements defined as "Features to Build" (Outputs) rather than "Problems to Solve"?
            3. Does the culture celebrate "Task Completion" over "Value Realization"?
            </criteria>
        </item>`
  }
};

// 6. THE SERVICE
export const knowledgeBaseService = {
    async fetchStrategicPlaybook(): Promise<string> {
        let tactics: StrategicTactic[] = [];
        let blobUrl: string | undefined = undefined;

        // --- HARDCODED FAILSAFE DEFAULT (SECURITY POLICY OVERRIDE) ---
        // Ensures functionality even if Vercel Environment Variables are not injected during build.
        const HARDCODED_URL = "https://l9fgwjm9p1o6atow.public.blob.vercel-storage.com/tactics.json";

        // 1. Try Standard Vite Injection
        const meta = import.meta as any;
        if (meta?.env?.VITE_TACTICS_URL) {
            blobUrl = meta.env.VITE_TACTICS_URL;
        }

        // 2. Fallback to process.env (Vite Config 'define')
        if (!blobUrl) {
            try {
                // @ts-ignore
                if (typeof process !== 'undefined' && process.env?.VITE_TACTICS_URL) {
                     // @ts-ignore
                    blobUrl = process.env.VITE_TACTICS_URL;
                }
            } catch (e) {
                // Ignore environment access errors
            }
        }

        // 3. Final Hardcoded Fallback
        if (!blobUrl) {
            console.info("[KnowledgeBase] VITE_TACTICS_URL missing. Using built-in fallback source.");
            blobUrl = HARDCODED_URL;
        }

        try {
            console.log(`[KnowledgeBase] Fetching strategy DB...`);
            const response = await fetch(blobUrl, {
                method: 'GET',
                headers: { 'Accept': 'application/json' },
                cache: 'force-cache' 
            });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            tactics = await response.json();
        } catch (error) {
            console.error("[KnowledgeBase] Error fetching remote DB:", error);
            // If even the hardcoded URL fails (e.g. network down), use the minimal local array
            tactics = FALLBACK_TACTICS; 
        }

        const formattedContext = tactics.map(t => {
            let entry = `[${t.category}] IF FOUND "${t.problem_pattern}" -> PRESCRIBE "${t.solution_mechanism}". \n   PROOF: ${t.case_study}`;
            if (t.resource_label) {
                entry += `\n   REFERENCE METHODOLOGY: ${t.resource_label}`;
            }
            return entry;
        }).join("\n\n");

        return `<VERIFIED_TACTICS_DATABASE>\n${formattedContext}\n</VERIFIED_TACTICS_DATABASE>`;
    }
};
