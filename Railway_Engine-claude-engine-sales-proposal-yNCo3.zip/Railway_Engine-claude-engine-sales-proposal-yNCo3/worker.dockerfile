
# ---------------------------------------
# Stage 1: Build the React Application
# ---------------------------------------
FROM node:18-alpine AS builder
WORKDIR /app

# Copy dependency definitions
COPY package*.json ./

# Install all dependencies (including devDeps for building)
RUN npm install

# Copy source code
COPY . .

# Build the Vite application to /app/dist
# Note: VITE_TACTICS_URL relies on the hardcoded fallback in knowledge_base.ts
# if env vars are not present at build time, which is fine for this architecture.
RUN npm run build

# ---------------------------------------
# Stage 2: Serve the Application
# ---------------------------------------
FROM node:18-alpine
WORKDIR /app

# Copy built assets from builder stage
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/package*.json ./

# Install only production dependencies (Express, Cors)
RUN npm install --omit=dev

# Copy the Express server
COPY server.js .

# Environment setup
ENV NODE_ENV=production
EXPOSE 8080

# Start the server
CMD ["node", "server.js"]
