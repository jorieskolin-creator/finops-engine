
import express from 'express';
import path from 'path';
import cors from 'cors';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// --- HEALTH CHECK ENDPOINT (Critical for Railway) ---
// Railway checks this to ensure the app is alive.
// We answer instantly to prevent SIGTERM kills.
app.get('/health', (req, res) => {
    res.status(200).send('OK');
});

// API Proxy for Gemini
// This replaces the Vercel Function mechanism
app.post('/api/generate', async (req, res) => {
    // Railway will inject API_KEY via environment variables
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
        console.error("Configuration Error: API_KEY missing.");
        return res.status(500).json({ error: "Server Configuration Error: API_KEY is missing." });
    }

    try {
        const { model, contents, systemInstruction } = req.body;
        // Default to flash if not provided
        const modelName = model || 'gemini-3-flash-preview';
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${apiKey}`;

        const payload = {
            contents,
            generationConfig: { responseMimeType: "application/json" }
        };
        if (systemInstruction) {
            payload.systemInstruction = { 
                parts: [{ text: typeof systemInstruction === 'string' ? systemInstruction : JSON.stringify(systemInstruction) }] 
            };
        }

        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            const txt = await response.text();
            console.error("Gemini API Error:", txt);
            return res.status(response.status).json({ error: txt });
        }

        const data = await response.json();
        const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "{}";
        res.json({ text });

    } catch (error) {
        console.error("Proxy Internal Error:", error);
        res.status(500).json({ error: error.message });
    }
});

// Serve Static Files (Vite Build)
app.use(express.static(path.join(__dirname, 'dist')));

// SPA Fallback (for client-side routing)
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
});
