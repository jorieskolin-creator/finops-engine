
import React, { useMemo, useState } from 'react';
import { DiagnosticResult, AuditItem } from '../types.ts';
import { BATCH_DEFINITIONS } from '../knowledge_base.ts';
import { downloadReport, downloadRawJson, downloadMarkdown, downloadText, redactText } from '../services/exportService.ts';
import { MarkdownRenderer } from './DashboardComponents.tsx';

// --- HELPER FOR DEFINITIONS ---
const parseDefinitions = (xmlString: string) => {
    const items = [];
    const itemRegex = /<item id="([^"]+)">([\s\S]*?)<\/item>/g;
    let match;
    while ((match = itemRegex.exec(xmlString)) !== null) {
        const id = match[1];
        const content = match[2];
        const titleMatch = content.match(/<title>([\s\S]*?)<\/title>/);
        const descMatch = content.match(/<description>([\s\S]*?)<\/description>/);
        
        items.push({
            id,
            title: titleMatch ? titleMatch[1].trim() : "Unknown",
            description: descMatch ? descMatch[1].trim() : ""
        });
    }
    return items;
};

const useAuditMetadata = (isTaylorism: boolean) => {
    return useMemo(() => {
        const map = new Map<string, { title: string, description: string }>();
        Object.entries(BATCH_DEFINITIONS).forEach(([colKey, defs]) => {
            const xml = isTaylorism ? defs.taylorism : defs.adaptability;
            const items = parseDefinitions(xml);
            items.forEach(item => map.set(item.id, { 
                title: item.title, 
                description: item.description 
            }));
        });
        return map;
    }, [isTaylorism]);
};

// --- SUB-COMPONENT: STATIC GAUGE ---
const ReportGauge = ({ value, label, color }: { value: number, label: string, color: string }) => (
    <div className="flex flex-col items-center justify-center p-4 border border-slate-200 rounded-xl bg-white flex-1 min-w-[120px]">
        <div className="relative w-16 h-16 mb-2">
            <svg className="w-full h-full" viewBox="0 0 36 36">
                <path
                    className="text-slate-100"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="3"
                />
                <path
                    style={{ color }}
                    strokeDasharray={`${value}, 100`}
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="3"
                    className="animate-[spin_1s_ease-out_reverse]" 
                />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center font-display font-bold text-slate-900 text-lg">
                {Math.round(value)}<span className="text-[10px] text-slate-400 -mt-1">%</span>
            </div>
        </div>
        <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider text-center">{label}</span>
    </div>
);

// --- MAIN REPORT COMPONENT ---
export const ReportView: React.FC<{ result: DiagnosticResult, onBack: () => void, onDownload: () => void }> = ({ result, onBack, onDownload }) => {
    const adaptMeta = useAuditMetadata(false);
    const taylorMeta = useAuditMetadata(true);
    const metrics = result.phase_2_validation.metrics;
    
    // REDACTION STATE
    const [isRedacted, setIsRedacted] = useState(false);

    // Helper to render text safely
    // Note: We redact first (replaces with blocks), then blur for extra visual effect if desired.
    const renderSafe = (text: string | undefined) => {
        if (!text) return null;
        return isRedacted ? redactText(text) : text;
    };

    return (
        <div className="bg-slate-100 min-h-screen pb-20 pt-10 px-4 md:px-0 font-sans print:bg-white print:p-0 print:pt-0 relative overflow-hidden">
            
            {/* WATERMARK OVERLAY WHEN REDACTED */}
            {isRedacted && (
                <div className="fixed inset-0 pointer-events-none z-0 flex items-center justify-center overflow-hidden">
                    <div className="absolute inset-0 bg-slate-900/5 backdrop-blur-[1px]"></div>
                    <div className="-rotate-12 transform scale-150 whitespace-nowrap text-[12rem] md:text-[18rem] font-black text-slate-900/5 select-none uppercase">
                        Classified
                    </div>
                </div>
            )}

            {/* TOOLBAR (Hidden when printing) */}
            <div className="max-w-[210mm] mx-auto mb-8 flex flex-col md:flex-row justify-between items-center gap-4 print:hidden relative z-10">
                <button onClick={onBack} className="flex items-center gap-2 text-slate-600 hover:text-slate-900 font-bold transition-colors">
                    <span className="bg-white p-2 rounded-full shadow-sm">←</span> Back to Dashboard
                </button>
                <div className="flex gap-3 items-center bg-white p-2 rounded-2xl shadow-sm border border-slate-200">
                    
                    {/* PRIVACY TOGGLE */}
                    <button 
                        onClick={() => setIsRedacted(!isRedacted)}
                        className={`relative flex items-center gap-3 px-4 py-2 rounded-xl transition-all duration-300 border ${isRedacted ? 'bg-slate-900 border-slate-900 text-white shadow-md' : 'bg-white border-transparent text-slate-500 hover:bg-slate-50'}`}
                    >
                        <div className={`w-2 h-2 rounded-full transition-colors ${isRedacted ? 'bg-emerald-400 animate-pulse' : 'bg-slate-300'}`}></div>
                        <span className="text-xs font-bold uppercase tracking-widest">{isRedacted ? 'Redaction Active' : 'Redaction Off'}</span>
                        {/* Switch UI */}
                        <div className={`w-8 h-4 rounded-full relative transition-colors ml-2 ${isRedacted ? 'bg-slate-700' : 'bg-slate-200'}`}>
                            <div className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-all duration-300 ${isRedacted ? 'left-4.5' : 'left-0.5'}`}></div>
                        </div>
                    </button>

                    <div className="h-6 w-px bg-slate-200 mx-1"></div>

                    <button onClick={() => window.print()} className="text-slate-500 hover:text-slate-900 p-2 rounded-lg hover:bg-slate-50 transition-colors" title="Print PDF">
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>
                    </button>
                    
                    <button 
                        onClick={() => downloadReport(result, isRedacted)} 
                        className="bg-cyan-500 hover:bg-cyan-600 text-white shadow-md shadow-cyan-500/20 px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-2"
                    >
                        <span>Download HTML</span>
                    </button>
                </div>
            </div>

            {/* A4 PAPER CONTAINER */}
            <div className="bg-white shadow-2xl max-w-[210mm] min-h-[297mm] mx-auto p-[15mm] md:p-[20mm] text-slate-900 print:shadow-none print:max-w-none print:w-full print:mx-0 print:p-0 relative z-10">
                
                {/* HEADER */}
                <header className="border-b-4 border-slate-900 pb-6 mb-10 flex justify-between items-end">
                    <div>
                        <h1 className="font-display font-black text-4xl tracking-tight mb-2 text-slate-900">Strategic Diagnostic</h1>
                        <div className="flex items-center gap-3">
                            <span className={`px-2 py-0.5 rounded font-mono text-xs font-bold uppercase tracking-widest border ${isRedacted ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-500 border-slate-200'}`}>
                                {isRedacted ? 'REDACTED COPY' : 'INTERNAL USE ONLY'}
                            </span>
                            <span className="text-slate-400 font-mono text-xs uppercase tracking-widest">
                                {new Date().toLocaleDateString()}
                            </span>
                        </div>
                    </div>
                    <div className="text-right hidden sm:block">
                         <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1">Modernization Engine</div>
                         <div className="text-base font-bold text-slate-700">Forensic Suite v2.0</div>
                    </div>
                </header>

                {/* SECTION 1: EXECUTIVE BRIEFING */}
                <section className="mb-12">
                    <div className="flex items-center gap-3 mb-6">
                         <span className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center text-sm font-bold font-display">01</span>
                         <h2 className="font-display font-bold text-2xl text-slate-900">Executive Briefing</h2>
                    </div>

                    <div className="bg-slate-50 rounded-2xl p-8 border border-slate-100 print:border print:border-slate-300">
                        {/* 1.1 Verdict */}
                        <div className="mb-8 pb-8 border-b border-slate-200">
                             <span className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-2 block">System Verdict</span>
                             <h3 className="text-3xl md:text-4xl font-display font-black text-cyan-700 tracking-tight leading-tight">
                                {result.phase_3_strategy.visual_scorecard.headline}
                             </h3>
                        </div>

                        {/* 1.2 Gauge Banner */}
                        <div className="mb-8">
                            <span className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-4 block">Core Vital Signs</span>
                            <div className="flex flex-wrap gap-4">
                                <ReportGauge value={metrics.modernization_readiness} label="Adaptability Readiness" color="#06b6d4" />
                                <ReportGauge value={metrics.adaptability_ratio} label="Adaptability Level" color="#8b5cf6" />
                                <ReportGauge value={metrics.adaptability_potential} label="Potential Index" color="#a855f7" />
                                <ReportGauge value={metrics.taylorism_ratio} label="Rigidity Level" color="#f43f5e" />
                                <ReportGauge value={metrics.taylorism_inertia} label="Inertia Burden" color="#e11d48" />
                            </div>
                        </div>

                        {/* 1.3 Narrative */}
                        <div>
                            <span className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-4 block">Strategic Analysis</span>
                            <div className={isRedacted ? 'blur-[0.5px]' : ''}>
                                {/* ✅ FIXED: Pass custom text color for Report View so it isn't white-on-white */}
                                <MarkdownRenderer content={renderSafe(result.phase_3_strategy.executive_summary)} textColor="text-slate-900" />
                            </div>
                        </div>
                    </div>
                </section>

                {/* SECTION 2: ROADMAP (Page Break Friendly) */}
                <section className="mb-12 break-inside-avoid">
                    <div className="flex items-center gap-3 mb-6">
                         <span className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center text-sm font-bold font-display">02</span>
                         <h2 className="font-display font-bold text-2xl text-slate-900">Remediation Roadmap</h2>
                    </div>
                    
                    <div className="space-y-6">
                        {result.phase_3_strategy.remediation_roadmap.map((step, idx) => (
                            <div key={idx} className="border-l-4 border-cyan-500 pl-6 py-2 relative">
                                <div className="absolute -left-[11px] top-0 w-5 h-5 rounded-full border-4 border-white bg-cyan-500"></div>
                                <h3 className="font-bold text-lg mb-2 text-slate-900">{step.phase}</h3>
                                {/* Use MarkdownRenderer for clean formatting */}
                                <div className={`text-sm text-slate-700 ${isRedacted ? 'blur-[0.5px]' : ''}`}>
                                    {step.actions.map((act, i) => (
                                        <div key={i} className="flex items-start gap-2 mb-2">
                                            <span className="mt-1.5 w-1 h-1 rounded-full bg-cyan-400 flex-shrink-0"></span>
                                            <div className="leading-relaxed">
                                                {/* ✅ FIXED: Pass custom text color for Roadmap items */}
                                                <MarkdownRenderer content={renderSafe(act)} textColor="text-slate-700" />
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                </section>
                
                <div className="page-break w-full h-12 block print:hidden"></div>

                {/* SECTION 3: ADAPTABILITY AUDIT */}
                <section className="mb-12">
                     <div className="flex items-center gap-3 mb-8 pb-4 border-b border-cyan-100">
                         <span className="w-8 h-8 rounded-lg bg-cyan-600 text-white flex items-center justify-center text-sm font-bold font-display">03</span>
                         <h2 className="font-display font-bold text-2xl text-cyan-800">Forensic Audit: Adaptability</h2>
                    </div>

                    <div className="space-y-6">
                        {['A', 'B', 'C', 'D', 'E'].map(cat => (
                            <div key={cat}>
                                {Object.entries(result.phase_1_audit_logs.adaptability)
                                    .filter(([key]) => key.startsWith(cat))
                                    .map(([key, rawItem]) => {
                                        const item = rawItem as AuditItem;
                                        const def = adaptMeta.get(key) || { title: "Unknown", description: "" };
                                        return (
                                            <div key={key} className="mb-6 break-inside-avoid border border-slate-200 rounded-xl p-6 bg-white shadow-sm print:shadow-none print:border-slate-300">
                                                <div className="flex justify-between items-start mb-3">
                                                    <div className="flex items-center gap-3">
                                                        <span className="font-mono font-bold text-slate-400 bg-slate-50 px-2 py-1 rounded text-xs">{key}</span>
                                                        <h4 className="font-bold text-slate-900 text-sm">{def.title}</h4>
                                                    </div>
                                                    <span className={`text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider ${
                                                        item.status === 'OK' ? 'bg-cyan-100 text-cyan-800' :
                                                        item.status === 'NOK' ? 'bg-slate-100 text-slate-400' :
                                                        'bg-indigo-100 text-indigo-800'
                                                    }`}>{item.status}</span>
                                                </div>
                                                
                                                <p className="text-xs text-slate-600 italic mb-4 leading-relaxed">{def.description}</p>
                                                
                                                <div className="bg-slate-50 p-4 rounded-lg border border-slate-100 print:bg-white print:border-slate-200">
                                                    <div className="mb-3">
                                                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">AI Reasoning</span>
                                                        <div className={`text-sm text-slate-800 leading-relaxed font-medium ${isRedacted ? 'blur-[1px]' : ''}`}>
                                                            {/* ✅ FIXED: Pass custom text color for AI Reasoning */}
                                                            <MarkdownRenderer content={renderSafe(item.reasoning)} textColor="text-slate-800" />
                                                        </div>
                                                    </div>
                                                    {item.evidence && (
                                                        <div className="pt-3 border-t border-slate-200/60">
                                                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Evidence</span>
                                                            <p className={`text-xs font-mono text-slate-600 ${isRedacted ? 'blur-[2px]' : ''}`}>
                                                                "{renderSafe(item.evidence)}"
                                                            </p>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        );
                                })}
                            </div>
                        ))}
                    </div>
                </section>

                {/* SECTION 4: TAYLORISM AUDIT */}
                <section className="mb-12">
                     <div className="flex items-center gap-3 mb-8 pb-4 border-b border-rose-100">
                         <span className="w-8 h-8 rounded-lg bg-rose-600 text-white flex items-center justify-center text-sm font-bold font-display">04</span>
                         <h2 className="font-display font-bold text-2xl text-rose-800">Forensic Audit: Taylorism</h2>
                    </div>

                    <div className="space-y-6">
                        {['A', 'B', 'C', 'D', 'E'].map(cat => (
                            <div key={cat}>
                                {Object.entries(result.phase_1_audit_logs.taylorism)
                                    .filter(([key]) => key.startsWith(cat))
                                    .map(([key, rawItem]) => {
                                        const item = rawItem as AuditItem;
                                        const def = taylorMeta.get(key) || { title: "Unknown", description: "" };
                                        return (
                                            <div key={key} className="mb-6 break-inside-avoid border border-slate-200 rounded-xl p-6 bg-white shadow-sm print:shadow-none print:border-slate-300">
                                                <div className="flex justify-between items-start mb-3">
                                                    <div className="flex items-center gap-3">
                                                        <span className="font-mono font-bold text-slate-400 bg-slate-50 px-2 py-1 rounded text-xs">{key}</span>
                                                        <h4 className="font-bold text-slate-900 text-sm">{def.title}</h4>
                                                    </div>
                                                    <span className={`text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider ${
                                                        item.status === 'OK' ? 'bg-emerald-100 text-emerald-800' :
                                                        item.status === 'NOK' ? 'bg-rose-100 text-rose-800' :
                                                        'bg-orange-100 text-orange-800'
                                                    }`}>{item.status}</span>
                                                </div>
                                                
                                                <p className="text-xs text-slate-600 italic mb-4 leading-relaxed">{def.description}</p>
                                                
                                                <div className="bg-slate-50 p-4 rounded-lg border border-slate-100 print:bg-white print:border-slate-200">
                                                    <div className="mb-3">
                                                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">AI Reasoning</span>
                                                        <div className={`text-sm text-slate-800 leading-relaxed font-medium ${isRedacted ? 'blur-[1px]' : ''}`}>
                                                             {/* ✅ FIXED: Pass custom text color for AI Reasoning */}
                                                             <MarkdownRenderer content={renderSafe(item.reasoning)} textColor="text-slate-800" />
                                                        </div>
                                                    </div>
                                                    {item.evidence && (
                                                        <div className="pt-3 border-t border-slate-200/60">
                                                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Evidence</span>
                                                            <p className={`text-xs font-mono text-slate-600 ${isRedacted ? 'blur-[2px]' : ''}`}>
                                                                "{renderSafe(item.evidence)}"
                                                            </p>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        );
                                })}
                            </div>
                        ))}
                    </div>
                </section>

                {/* NEW: INTEROPERABILITY HUB (Replaces old JSON-only footer) */}
                <div className="mt-12 pt-10 border-t-2 border-slate-100 print:hidden">
                    <div className="text-center mb-8">
                        <h3 className="text-sm font-bold uppercase tracking-widest text-slate-500 mb-2">Interoperability & Export Hub</h3>
                        <p className="text-xs text-slate-400 max-w-lg mx-auto">
                            Extract this strategy as raw input material for other AI agents, simulators, or documentation tools.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl mx-auto">
                        
                        {/* OPTION 1: MARKDOWN (For AI) */}
                        <button 
                            onClick={() => downloadMarkdown(result)}
                            className="group p-4 rounded-xl border border-slate-200 bg-white hover:border-indigo-400 hover:shadow-lg hover:shadow-indigo-100 transition-all text-left"
                        >
                            <div className="flex items-center gap-3 mb-2">
                                <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-xs group-hover:bg-indigo-500 group-hover:text-white transition-colors">
                                    MD
                                </div>
                                <span className="font-bold text-slate-700 text-sm">AI Context (.md)</span>
                            </div>
                            <p className="text-[10px] text-slate-400">Optimized structure for uploading to ChatGPT, Claude, or NotebookLM.</p>
                        </button>

                        {/* OPTION 2: PLAIN TEXT (For Word/Docs) */}
                        <button 
                            onClick={() => downloadText(result)}
                            className="group p-4 rounded-xl border border-slate-200 bg-white hover:border-cyan-400 hover:shadow-lg hover:shadow-cyan-100 transition-all text-left"
                        >
                            <div className="flex items-center gap-3 mb-2">
                                <div className="w-8 h-8 rounded-lg bg-cyan-50 text-cyan-600 flex items-center justify-center font-bold text-xs group-hover:bg-cyan-500 group-hover:text-white transition-colors">
                                    TXT
                                </div>
                                <span className="font-bold text-slate-700 text-sm">Plain Text (.txt)</span>
                            </div>
                            <p className="text-[10px] text-slate-400">Universal format. Easy copy-paste into Word, Google Docs, or email.</p>
                        </button>

                        {/* OPTION 3: JSON (For Code) */}
                        <button 
                            onClick={() => downloadRawJson(result)}
                            className="group p-4 rounded-xl border border-slate-200 bg-white hover:border-emerald-400 hover:shadow-lg hover:shadow-emerald-100 transition-all text-left"
                        >
                            <div className="flex items-center gap-3 mb-2">
                                <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-xs group-hover:bg-emerald-500 group-hover:text-white transition-colors">
                                    {'{ }'}
                                </div>
                                <span className="font-bold text-slate-700 text-sm">System Data (.json)</span>
                            </div>
                            <p className="text-[10px] text-slate-400">Full forensic dataset for import into the Transformation Simulator.</p>
                        </button>
                    </div>
                </div>

                {/* FOOTER */}
                <footer className="text-center border-t border-slate-200 pt-8 mt-12 pb-8">
                    <p className="text-slate-400 text-xs uppercase tracking-widest font-bold">Generated by Modernization Engine v2.0</p>
                    <p className="text-slate-300 text-[10px] mt-1">Strictly Confidential • {new Date().getFullYear()}</p>
                </footer>
            </div>
        </div>
    );
};
